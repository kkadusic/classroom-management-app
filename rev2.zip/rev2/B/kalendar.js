let Kalendar = (function(){
   
    var br1=0;
    var br2=0;
    var br=0;

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
      var pocetakCasa=document.getElementById("pocetak").value;
      var vanrednaCheck=document.getElementById("vanredna");
      var krajCasa=document.getElementById("kraj").value;
      var sala1=document.getElementById("sala");
      var odabranaSala=sala1.options[sala1.selectedIndex].text;
      var mjeseci=[31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      var trazeniMjesec=mjeseci[mjesec];                        //mjesec u kalendaru u kojem bojimo
      var kal=document.getElementById('kalendar');              //cijeli kalendar
      var daniUKalendaru=kal.getElementsByTagName('li');        //samo kvadratici
      for(var i=8;i<(trazeniMjesec+12);i++){
        if(daniUKalendaru[i].className!="prazno"){
            daniUKalendaru[i].className="slobodna";
         }
      }
      if(document.getElementById("periodicna").checked){
      for(var i=8;i<(trazeniMjesec+12);i++){                    //za periodicne
        for(var j=0;j<p.dan.length;j++){
            if(p.dan[j]==i-8 && pocetakCasa==p.pocetak[j] && krajCasa==p.kraj[j] && odabranaSala==p.naziv[j]){
                for(var k=i;k<(trazeniMjesec+12);k+=7){
          if(kalendarRef.getElementsByTagName('li')[k].className!="prazno"){
             kalendarRef.getElementsByTagName('li')[k].className="zauzeta";
          }
         
        }
        }
        }
        } 
    }
    else if(document.getElementById("periodicna").checked==false){
        for(var i=8;i<(trazeniMjesec+12);i++){                    //za periodicne
          for(var j=0;j<p.dan.length;j++){
              if(p.dan[j]==i-8 && pocetakCasa==p.pocetak[j] && krajCasa==p.kraj[j] && odabranaSala==p.naziv[j]){
                  for(var k=i;k<(trazeniMjesec+12);k+=7){
                    if(kalendarRef.getElementsByTagName('li')[k].className!="prazno"){
                        kalendarRef.getElementsByTagName('li')[k].className="slobodna";
                     }
          }
          }
          }
          } 
      }
               //^zavrsili za periodicne^
    var datumZauzeca=v.datum; //niz stringova
        var nizDana=[];
        var nizDatuma=[];
        //da dobijemo dane i mjesece 
        for(var i=0;i<datumZauzeca.length;i++){ //da izvadimo dane u stringovima
            for(var j=0;j<2;j++){
                var tmp=datumZauzeca[i];
                if(tmp[0]=='0'){nizDana[i]=tmp[1]; break;}
                else if(j==0 && tmp[0]!='0'){nizDana[i]=tmp[0];}
                else if(tmp[0]!='0' && j!=0){nizDana[i]+=tmp[j]; break;}
            }
        }
        for(var i=0;i<datumZauzeca.length;i++){ //da izvadimo mjesece u stringovima
            for(var j=3;j<5;j++){
                var tmp=datumZauzeca[i];
                if(tmp[3]=='0'){nizDatuma[i]=tmp[4]; break;}
                else if(j==3 && tmp[3]!='0'){nizDatuma[i]=tmp[3];}
                else if(tmp[3]!='0' && j!=3){nizDatuma[i]+=tmp[j]; break;}
            }
        }
    if(vanrednaCheck.checked){                              // <---za vanredne
        for(var i=8;i<(trazeniMjesec+12);i++){                    
            for(var s=0;s<nizDana.length;s++){
                if(parseInt(nizDana[s])==i-8 && pocetakCasa==v.pocetak[s] && krajCasa==v.kraj[s] && odabranaSala==v.naziv[s] /*&& mjesec==nizDatuma[s]*/){ 
              if(kalendarRef.getElementsByTagName('li')[i+3].className!="prazno"){
                kalendarRef.getElementsByTagName('li')[i+3].className="zauzeta";
              }
            }
            }
      }
    }
         if(vanrednaCheck.checked==false){                              // <---za vanredne
        for(var i=8;i<(trazeniMjesec+12);i++){                    
            for(var s=0;s<nizDana.length;s++){
                if(parseInt(nizDana[s])==i-8 && pocetakCasa==v.pocetak[s] && krajCasa==v.kraj[s] && odabranaSala==v.naziv[s]){ 
              if(kalendarRef.getElementsByTagName('li')[i+3].className!="prazno"){
                kalendarRef.getElementsByTagName('li')[i+3].className="slobodna";
              }
            }
            }
      }
   }
}

    function ucitajPodatkeImpl(periodicna, vanredna){
        var kal=document.getElementById('kalendar');
        var daniUSedmici=['PON','UTO','SRI','CET','PET','SUB','NED'];
        if(document.getElementById("periodicna").checked || document.getElementById("periodicna").checked==false){
        for(var i=0;i<Object.keys(p).length;i++){      // periodicni casovi 
            for(var j=0;j<p.dan.length;j++){
                var odabraniDan=p.dan[j];
                for(var k=0;k<daniUSedmici.length;k++){         //dan u sedmici
                    if(odabraniDan==k){
                        obojiZauzecaImpl(kal,new Date().getMonth(),p.naziv[j], p.pocetak[j],p.kraj[j]);
                    }
                }
            }
        } 
    }           //ovo je bilo za periodicne casove
        var datumZauzeca=v.datum; //niz stringova
        var nizDana=[];
        var nizDatuma=[];
        //da dobijemo dane i mjesece 
        for(var i=0;i<datumZauzeca.length;i++){ //da izvadimo dane u stringovima
            for(var j=0;j<2;j++){
                var tmp=datumZauzeca[i];
                if(tmp[0]=='0'){nizDana[i]=tmp[1]; break;}
                else if(j==0 && tmp[0]!='0'){nizDana[i]=tmp[0];}
                else if(tmp[0]!='0' && j!=0){nizDana[i]+=tmp[j]; break;}
            }
        }
        for(var i=0;i<datumZauzeca.length;i++){ //da izvadimo mjesece u stringovima
            for(var j=3;j<5;j++){
                var tmp=datumZauzeca[i];
                if(tmp[3]=='0'){nizDatuma[i]=tmp[4]; break;}
                else if(j==3 && tmp[3]!='0'){nizDatuma[i]=tmp[3];}
                else if(tmp[3]!='0' && j!=3){nizDatuma[i]+=tmp[j]; break;}
            }
        }
                //dobili smo dane i mjesece u stringovima
        if(document.getElementById("vanredna").checked==true || document.getElementById("vanredna").checked==false){
        for(var i=0; i<Object.keys(v).length;i++){
            for(var j=0;j<v.pocetak.length;j++){
                var danZauzeca=v.pocetak[j];
                for(var k=0;k<32;k++){
                    if(parseInt(nizDana[j])==k){
                        obojiZauzecaImpl(kal,nizDatuma[j],v.naziv[j], v.pocetak[j],v.kraj[j]);
                    }
                }
            }
        }
    }

    }
    function iscrtajKalendarImpl(kalendarRef, mjesec){
        
        var x=kalendarRef.getElementsByTagName('li');
        var noviMjesec=' ';
        var mjeseci=['JANUAR', 'FEBRUAR', 'MART', 'APRIL','MAJ', 'JUNI', 'JULI','AUGUST','SEPTEMBAR', 'OKTOBAR', 'NOVEMBAR', 'DECEMBAR'];
        this.funkcijaNazad=function(){ //nazad
            br1++;
            if(br1>br2){
                br=br1-br2;               
                for(var i=mjeseci.length-1;i>=0;i--){
                    if(mjesec==i && (mjesec-br)==0){
                        noviMjesec=mjeseci[i-br];
                        redniBrojMjeseca=i-br;
                        x[0].innerHTML=noviMjesec;
                        document.getElementById("d1").style.visibility='hidden';
                    }
                    else if(i!=0 && mjesec==i){
                     document.getElementById("d1").style.visibility='visible';
                     noviMjesec=mjeseci[i-br];
                     redniBrojMjeseca=i-br;
                     x[0].innerHTML=noviMjesec;
                     break;
                    }
            }
            }
            else if(br2>br1){
                br=br2-br1;
                for(var i=mjeseci.length-1;i>=0;i--){
                    if(mjesec==i && (mjesec-br)==0){
                        noviMjesec=mjeseci[i+br];
                        redniBrojMjeseca=i+br;
                        x[0].innerHTML=noviMjesec;
                        document.getElementById("d2").style.visibility='hidden';
                    }
                    else if(i!=0 && mjesec==i){
                     document.getElementById("d2").style.visibility='visible';
                     noviMjesec=mjeseci[i+br];
                     redniBrojMjeseca=i+br;
                     x[0].innerHTML=noviMjesec;
                     break;
                    }
            }
            }
            else if(br1==br2){
                x[0].innerHTML=mjeseci[mjesec];
                document.getElementById("d2").style.visibility='visible';
            }
            for(var i=0;i<mjeseci.length;i++){          //UZIMAMO MJESEC NA OSNOVU KOJEG CRTAMO KALENDAR
                if(x[0].innerHTML==mjeseci[i]){
                    noviMjesec=x[0].innerHTML;
                }
            }
            var daniKalendara= document.getElementById("daniKalendara");
            if(noviMjesec=='DECEMBAR'){
                for(var i=0;i<2;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }    
            daniKalendara.children[36].className='slobdnda';
            kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='NOVEMBAR'){
                for(var i=0;i<2;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[34].className='prazno';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='OKTOBAR'){
                for(var i=0;i<6;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[31].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='SEPTEMBAR'){
                for(var i=0;i<5;i++)
                {var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);}
                daniKalendara.children[36].className='prazno';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='AUGUST'){
                for(var i=0;i<3;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[33].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='JULI'){
                for(var i=0;i<4;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[33].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='JUNI'){
                for(var i=0;i<5;i++){
                    var novi=document.createElement("li");
                    novi.setAttribute("class","prazno");
                    daniKalendara.appendChild(novi);
                    daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
                }    
                daniKalendara.children[35].className='prazno';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='MAJ'){
                for(var i=0;i<3;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[32].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='APRIL'){
                for(var i=0;i<2;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[30].className='prazno';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='MART'){
                for(var i=0;i<4;i++){
                    var novi=document.createElement("li");
                    novi.setAttribute("class","prazno");
                    daniKalendara.appendChild(novi);
                    daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
                }    
                daniKalendara.children[34].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='FEBRUAR'){
                daniKalendara.children[34].className='prazno';
                daniKalendara.children[33].className='prazno';
                daniKalendara.children[32].className='prazno';
                kalendarRef.children[2]=daniKalendara;
            }
            if(noviMjesec=='JANUAR'){
                for(var i=0;i<3;i++){
                    daniKalendara.removeChild(daniKalendara.childNodes[0]);
                }
                daniKalendara.children[31].className='slobodna';
                daniKalendara.children[30].className='slobodna';
                daniKalendara.children[29].className='slobodna';
                kalendarRef.children[2]=daniKalendara;
            }
        }
    this.funkcijaNaprijed=function(){                                   //NAPRIJED !!!!
        br2++;
        if(br1>br2){
            br=br1-br2;
           
            for(var i=mjeseci.length-1;i>=0;i--){
                if(mjesec==i && (mjesec-br)==0){
                    noviMjesec=mjeseci[i-br];
                    redniBrojMjeseca=i-br;
                    x[0].innerHTML=noviMjesec;
                    document.getElementById("d1").style.visibility='hidden';
                }
                else if(i!=0 && mjesec==i){
                    document.getElementById("d2").style.visibility='visible';
                    document.getElementById("d1").style.visibility='visible';
                 noviMjesec=mjeseci[i-br];
                 redniBrojMjeseca=i-br;
                 x[0].innerHTML=noviMjesec;
                 break;
                }
              
        }
        }
        else if(br2>br1){
            br=br2-br1;
            for(var i=mjeseci.length-1;i>=0;i--){
                if(mjesec==i && (mjesec+br)==11){
                    noviMjesec=mjeseci[i+br];
                    redniBrojMjeseca=i+br;
                    x[0].innerHTML=noviMjesec;
                    document.getElementById("d2").style.visibility='hidden';
                }
                else if(i!=11 && mjesec==i){
                 document.getElementById("d1").style.visibility='visible';
                 document.getElementById("d2").style.visibility='visible';
                 noviMjesec=mjeseci[i+br];
                 redniBrojMjeseca=i+br;
                 x[0].innerHTML=noviMjesec;
                 break;
                }
        }
        }
        else if(br1==br2){
            document.getElementById("d1").style.visibility='visible';
            document.getElementById("d2").style.visibility='visible';
            x.innerHTML=mjeseci[mjesec];
        }

        for(var i=0;i<mjeseci.length;i++){          //UZIMAMO MJESEC NA OSNOVU KOJEG CRTAMO KALENDAR
            if(x.innerHTML==mjeseci[i]){
                noviMjesec=x.innerHTML;
            }
        }

        var daniKalendara= document.getElementById("daniKalendara");
        if(noviMjesec=='DECEMBAR'){
            for(var i=0;i<2;i++){
            var novi=document.createElement("li");
            novi.setAttribute("class","prazno");
            daniKalendara.appendChild(novi);
            daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            
        }
        daniKalendara.children[36].className='slobodna';
        kalendarRef.children[2]=daniKalendara;
        var sala1=document.getElementById("sala");
        var odabranaSala=sala1.options[sala1.selectedIndex].text;
        Kalendar.obojiZauzeca(kalendarRef,12,odabranaSala,"17:00", "18:00");
        }
        if(noviMjesec=='NOVEMBAR'){
            for(var i=0;i<3;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }
            daniKalendara.children[34].className='prazno';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='OKTOBAR'){
            for(var i=0;i<5;i++){
                daniKalendara.removeChild(daniKalendara.childNodes[0]);
            }
            daniKalendara.children[31].className='slobodna';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='SEPTEMBAR'){
            for(var i=0;i<3;i++)
            {var novi=document.createElement("li");
            novi.setAttribute("class","prazno");
            daniKalendara.appendChild(novi);
            daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);}
            daniKalendara.children[36].className='prazno';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='AUGUST'){
            for(var i=0;i<3;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='JULI'){
            for(var i=0;i<5;i++){
                daniKalendara.removeChild(daniKalendara.childNodes[0]);
            }
            daniKalendara.children[30].className='slobodna';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='JUNI'){
            for(var i=0;i<3;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }
            daniKalendara.children[35].className='prazno';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='MAJ'){
            for(var i=0;i<2;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }
            daniKalendara.children[32].className='slobodna';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='APRIL'){
            for(var i=0;i<4;i++){
                daniKalendara.removeChild(daniKalendara.childNodes[0]);
            }
            daniKalendara.children[30].className='prazno';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='MART'){
            daniKalendara.children[32].className='slobodna';
            daniKalendara.children[33].className='slobodna';
            daniKalendara.children[34].className='slobodna';
            kalendarRef.children[2]=daniKalendara;
        }
        if(noviMjesec=='FEBRUAR'){
            for(var i=0;i<3;i++){
                var novi=document.createElement("li");
                novi.setAttribute("class","prazno");
                daniKalendara.appendChild(novi);
                daniKalendara.insertBefore(novi,daniKalendara.childNodes[0]);
            }
            daniKalendara.children[32].className='prazno';
            daniKalendara.children[33].className='prazno';
            daniKalendara.children[34].className='prazno';
            kalendarRef.children[2]=daniKalendara;
        }
    }
}
    return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
    }
    }());
    
    //primjer korištenja modula
    //Kalendar.obojiZauzeca(document.getElementById('kalendar'), 1, '1-15', '12:00', '13:30');
    let p={dan: [1,3],
        semestar: ["zimski","zimski"],
        pocetak: ["10:00","17:00"],
        kraj: ["11:30","18:00"],
        naziv: ["VA1", "VA3"],
        predavac: ["Novica Nosovic", "Selma Rizvic"]};
      let v={datum: ["11.12.2019", "20.12.2019"],
             pocetak: ["10:00","17:00"],
             kraj: ["11:20","18:00"],
             naziv: ["VA1", "VA2"],
             predavac: ["Vensada Okanovic", "Anel Tanovic"]};

      window.onload=Kalendar.ucitajPodatke(p,v); 