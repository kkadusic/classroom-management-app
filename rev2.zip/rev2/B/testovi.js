let assert= chai.assert;
describe ('Kalendar', function(){
    describe('iscrtajKalendar()',function(){
        if('mjesec novembar ima 30 dana',function(){
            (new Kalendar.iscrtajKalendar(document.getElementById('kalendar'), 10)).funkcijaNazad();
            let kal=document.getElementById('kalendar');
            let kvadratici=kalendar.getElementsByTagName('li');
            let br=0;
                for(let i=0;i<45;i++){
                    if(kvadratici[i].className=='slobodna'){
                        br++;
                    }
                }
                assert.equal(br,30,"broj dana 30");
        });
    });
    describe('iscrtajKalendar()',function(){
        if('mjesec decembar ima 30 dana',function(){
            (new Kalendar.iscrtajKalendar(document.getElementById('kalendar'), 11)).funkcijaNazad();
            let kal=document.getElementById('kalendar');
            let kvadratici=kalendar.getElementsByTagName('li');
            let br=0;
                for(let i=0;i<45;i++){
                    if(kvadratici[i].className=='slobodna'){
                        br++;
                    }
                }
                assert.equal(br,31,"broj dana 31");
        });
    });
    describe('obojiZauzeca()',function(){
        it ('Kada nema parametara, ne boji se ni jedan dan', function(){
            Kalendar.obojiZauzeca(document.getElementById('kalendar'),11,'VA1','11:00','12:00');
            let kal=document.getElementById('kalendar');
            let kvadratici=kalendar.getElementsByTagName('li');
            let br=0;
                for(let i=0;i<45;i++){
                    if(kvadratici[i].className=='zauzeta'){
                        br++;
                    }
                }
                assert.equal(br,0,"broj zauzetih sala treba bit nula");
        });
    });
    describe('obojiZauzeca()',function(){
        it ('Pozivanje obojiZauzeca() dvaputa sa istim parametrima, ostaje isto obojenje', function(){
            Kalendar.obojiZauzeca(document.getElementById('kalendar'),11,'VA1','11:00','12:00');
            Kalendar.obojiZauzeca(document.getElementById('kalendar'),11,'VA1','11:00','12:00');

        });
    });
    
});