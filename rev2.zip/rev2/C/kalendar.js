/*
    kalendarRef je body tabele za kalendar
*/

let danas = new Date();
let trenutniMjesec = danas.getMonth();
let trenutnaGodina = danas.getFullYear();
let kalendarRef = document
  .getElementById("kalendar-tabela")
  .getElementsByTagName("tbody")[0];
let prethodniMjesecButton = document.getElementById("prethodni-btn");
let sljedeciMjesecButton = document.getElementById("sljedeci-btn");
let saleSelect = document.getElementById("sale-select");
let pocetakInput = document.getElementById("pocetak-input");
let krajInput = document.getElementById("kraj-input");

var Kalendar = (function() {
  let periodicnaZauzeca;
  let vanrednaZauzeca;
  const mjeseci = [
    "Januar",
    "Februar",
    "Mart",
    "April",
    "Maj",
    "Juni",
    "Juli",
    "August",
    "Septembar",
    "Oktobar",
    "Novembar",
    "Decembar"
  ];

  var ucitajPodatke = function(periodicna, vanredna) {
    periodicnaZauzeca = periodicna;
    vanrednaZauzeca = vanredna;
  };

  var obojiZauzeca = function(
    kalendarRef,
    mjesec,
    sala,
    vrijemePocetka,
    vrijemeKraja
  ) {
    if (!periodicnaZauzeca && !vanrednaZauzeca) {
      return;
    }

    let dani = kalendarRef.getElementsByTagName("td");
    for (let i = 0; i < dani.length; i++) {
        
      dani[i].getElementsByTagName("div")[0].classList.add("slobodnaSala");
    }

    // Bojenje zauzeca za periodicna zauzeca
    for (let i = 0; i < periodicnaZauzeca.length; i++) {
      if (periodicnaZauzeca[i].naziv === sala) {
        let danZauzeca = periodicnaZauzeca[i].dan;
        dani = kalendarRef.getElementsByTagName("td");

        if (periodicnaZauzeca[i].semestar === dajSemestar(mjesec)) {
          while (danZauzeca < dani.length) {
            if (dani[danZauzeca].innerText !== "") {
              dani[danZauzeca]
                .getElementsByTagName("div")[0]
                .classList.add("zauzetaSala");
              dani[danZauzeca]
                .getElementsByTagName("div")[0]
                .classList.remove("slobodnaSala");
            }
            danZauzeca += 7;
          }
        }
      }
    }

    // Bojenje zauzeca za vanredna zauzeca
    for (let i = 0; i < vanrednaZauzeca.length; i++) {
      if (periodicnaZauzeca[i].naziv === sala) {
        const danMjesecGodina = vanrednaZauzeca[i].datum.split(".");
        let datum = new Date(
          danMjesecGodina[2],
          danMjesecGodina[1] - 1,
          danMjesecGodina[0]
        );

        if (datum instanceof Date) {
          dani = kalendarRef.getElementsByTagName("td");

          if (datum.getMonth() === mjesec) {
            let danZauzeca = datum.getDate();

            for (let j = 0; j < dani.length; j++) {
              if (dani[j].textContent === danZauzeca.toString()) {
                dani[j]
                  .getElementsByTagName("div")[0]
                  .classList.add("zauzetaSala");
                dani[danZauzeca]
                  .getElementsByTagName("div")[0]
                  .classList.remove("slobodnaSala");
              }
            }
          }
        }
      }
    }
  };

  function dajSemestar(mjesec) {
    if (mjesec >= 6 && mjesec < 9) {
      return null;
    } else if (mjesec >= 1 && mjesec < 6) {
      return "ljetni";
    } else {
      return "zimski";
    }
  }

  var iscrtajKalendar = function(kalendarRef, mjesec) {
    let godina = new Date().getFullYear();
    kalendarRef.innerHTML = "";

    // Dodavanje mjeseca i godine u header tabele
    let godinaMjesec = document.getElementById("mjesec-godina");
    godinaMjesec.innerText = mjeseci[trenutniMjesec] + " " + trenutnaGodina;
    let prviDan = new Date(godina, mjesec).getDay();
    prviDan = prviDan === 0 ? 6 : prviDan - 1;
    let dan = 1;

    for (let i = 0; i < 6; i++) {
      let red = document.createElement("tr");

      for (let j = 0; j < 7; j++) {
        if (dan > dajBrojDana(godina, mjesec)) {
          break;
        } else {
          let celija = document.createElement("td");
          let zauzetaSlobodnaDiv = document.createElement("div");
          let celijaText;

          if (i === 0 && j < prviDan) {
            celijaText = document.createTextNode("");
          } else {
            celijaText = document.createTextNode(dan);
            dan++;
          }

          celija.appendChild(celijaText);

          celija.appendChild(zauzetaSlobodnaDiv);
          red.appendChild(celija);
        }
      }

      kalendarRef.appendChild(red);
    }
  };

  return {
    obojiZauzeca: obojiZauzeca,
    ucitajPodatke: ucitajPodatke,
    iscrtajKalendar: iscrtajKalendar
  };
})();

function dajBrojDana(godina, mjesec) {
  return 32 - new Date(godina, mjesec, 32).getDate();
}

function sljedeciMjesec() {
  if (trenutniMjesec < 11) {
    trenutniMjesec++;
    prethodniMjesecButton.disabled = false;
    prethodniMjesecButton.style.background = "white";
    prethodniMjesecButton.style.color = "darkcyan";
  }

  if (trenutniMjesec === 11) {
    sljedeciMjesecButton.disabled = true;
    sljedeciMjesecButton.style.background = "grey";
    sljedeciMjesecButton.style.color = "white";
  }

  Kalendar.iscrtajKalendar(kalendarRef, trenutniMjesec);
  Kalendar.obojiZauzeca(
    kalendarRef,
    trenutniMjesec,
    saleSelect.options[saleSelect.selectedIndex].value,
    pocetakInput.value,
    krajInput.value
  );
}

function prethodniMjesec() {
  if (trenutniMjesec > 0) {
    trenutniMjesec--;
    sljedeciMjesecButton.disabled = false;
    sljedeciMjesecButton.style.background = "white";
    sljedeciMjesecButton.style.color = "darkcyan";
  }

  if (trenutniMjesec === 0) {
    prethodniMjesecButton.disabled = true;
    prethodniMjesecButton.style.background = "grey";
    prethodniMjesecButton.style.color = "white";
  }

  Kalendar.iscrtajKalendar(kalendarRef, trenutniMjesec);
  Kalendar.obojiZauzeca(
    kalendarRef,
    trenutniMjesec,
    saleSelect.options[saleSelect.selectedIndex].value,
    pocetakInput.value,
    krajInput.value
  );
}

function handleFormChange() {
  Kalendar.obojiZauzeca(
    kalendarRef,
    trenutniMjesec,
    saleSelect.options[saleSelect.selectedIndex].value,
    pocetakInput.value,
    krajInput.value
  );
}

Kalendar.iscrtajKalendar(kalendarRef, new Date().getMonth());

const periodicna = [
  {
    dan: 0,
    semestar: "zimski",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "MA",
    predavac: "Vensada Okanović"
  },
  {
    dan: 1,
    semestar: "ljetni",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "MA",
    predavac: "Vensada Okanović"
  },
  {
    dan: 4,
    semestar: "zimski",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "MA",
    predavac: "Vensada Okanović"
  },
  {
    dan: 4,
    semestar: "zimski",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "MA",
    predavac: "Vensada Okanović"
  }
];

const vanredna = [
  {
    datum: "10.12.2019",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "VA1",
    predavac: "Željko Jurić"
  },
  {
    datum: "1.1.2019",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "VA1",
    predavac: "Željko Jurić"
  },
  {
    datum: "5.11.2019",
    pocetak: "12:00",
    kraj: "14:00",
    naziv: "VA1",
    predavac: "Željko Jurić"
  }
];

Kalendar.ucitajPodatke(periodicna, vanredna);
Kalendar.obojiZauzeca(
  kalendarRef,
  trenutniMjesec,
  saleSelect.options[saleSelect.selectedIndex].value,
  pocetakInput.value,
  krajInput.value
);
