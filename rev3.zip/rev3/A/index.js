const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();

app.use(express.static(__dirname + "/public"));
app.use(express.static(__dirname + "/slike"));
app.use(bodyParser.json());

app.get('/', function(req, res) {
    res.sendFile(__dirname + "/public/pocetna.html");
});

app.get('/zauzeca.json', function(req, res) {
    res.sendFile(__dirname + "/zauzeca.json");
});

function uporediVremena(vrijemePrvo, vrijemeDrugo) {

    if (vrijemePrvo === vrijemeDrugo) return 0;
    let nizPrvi = vrijemePrvo.split(":");
    let nizDrugi = vrijemeDrugo.split(":");
    if (eval(nizPrvi[0]) > eval(nizDrugi[0])) {
        return 1;
    }
    else if (eval(nizPrvi[0]) === eval(nizDrugi[0]) && eval(nizPrvi[1]) > eval(nizDrugi[1])) return 1;
    else return -1;

}

function jeLiVrijemeIzmedjuDrugaDva(prvoVrijeme, drugoVrijeme, treceVrijeme) {

    return uporediVremena(prvoVrijeme, drugoVrijeme) >= 0 && uporediVremena(prvoVrijeme, treceVrijeme) <= 0;

}

app.post('/zauzeca.json', function(req, res) {
    let tijelo = req.body;
    let danUMjesecu = tijelo['danUMjesecu'];
    let danUSedmici = tijelo['danUSedmici'];
    let mjesec = tijelo['mjesec'];
    let sala = tijelo['sala'];
    let pocetak = tijelo['pocetak'];
    let kraj = tijelo['kraj'];
    let periodicnaRezervacija = tijelo['periodicnaRezervacija'];
    fs.readFile('zauzeca.json', function(greska, iscitaniSadrzajDatoteke) {
        if (greska) return console.error(greska);
        let vraceniJsonZauzeca = iscitaniSadrzajDatoteke;
        let vraceniObjekatZauzeca = JSON.parse(vraceniJsonZauzeca);

        let periodicnaZauzeca = vraceniObjekatZauzeca.periodicna;
        let vanrednaZauzeca = vraceniObjekatZauzeca.vanredna;
        
        let trenutnaGodina = new Date().getFullYear();
        let brojDanaMjeseca = new Date(trenutnaGodina, mjesec + 1, 0).getDate();
        let i;
        // Provjera periodicnih zauzeca
        let filtriraniNizPeriodicnihZauzeca = periodicnaZauzeca.filter(function(zauzece) {
            let danZauzeca = zauzece.dan;
            let danSedmice = danUSedmici;
            if (danSedmice === 0) danSedmice = 7;
            return zauzece.naziv === sala && danSedmice === danZauzeca + 1
            && (jeLiVrijemeIzmedjuDrugaDva(zauzece.pocetak, pocetak, kraj) || jeLiVrijemeIzmedjuDrugaDva(zauzece.kraj, pocetak, kraj)
            || jeLiVrijemeIzmedjuDrugaDva(pocetak, zauzece.pocetak, zauzece.kraj) || jeLiVrijemeIzmedjuDrugaDva(kraj, zauzece.pocetak, zauzece.kraj))
            && ((zauzece.semestar === "zimski" && (mjesec === 0 || mjesec >= 9 && mjesec <= 11)) 
            || (zauzece.semestar === "ljetni" && (mjesec >= 1 && mjesec <= 5))) 
            && (!((uporediVremena(zauzece.kraj, pocetak) == 0 && uporediVremena(zauzece.pocetak, zauzece.kraj) <= 0) 
            || (uporediVremena(kraj, zauzece.pocetak) == 0 && uporediVremena(pocetak, kraj) <= 0)));
        });
        if (filtriraniNizPeriodicnihZauzeca.length != 0) {
            res.set('Content-Type', 'text/plain; charset=utf-8');
            let praviMjesec = mjesec + 1;
            let porukaGreske = "Nije moguće rezervisati salu " + sala + " za navedeni datum " + 
             ((danUMjesecu < 10) ? ("0" + danUMjesecu) : danUMjesecu) + "/" + ((praviMjesec < 10) ? ("0" + praviMjesec) : praviMjesec) + "/" + trenutnaGodina + 
             " i termin od " + pocetak + " do " + kraj + "!";
            res.status(200).send(porukaGreske);
            return;
        }
        // Provjera vanrednih zauzeca
        if (!periodicnaRezervacija) {
            let filtriraniNizVanrednihZauzeca = vanrednaZauzeca.filter(function(zauzece) {
                let nizRazdvojen = zauzece.datum.split(".");
                nizRazdvojen.reverse();
                let noviDatumFormat = nizRazdvojen.join("-");
                let datumZauzeca = new Date(noviDatumFormat);
                return datumZauzeca.getFullYear() == trenutnaGodina 
                && datumZauzeca.getMonth() == mjesec
                && datumZauzeca.getDate() == danUMjesecu
                && zauzece.naziv === sala 
                && (jeLiVrijemeIzmedjuDrugaDva(zauzece.pocetak, pocetak, kraj) || jeLiVrijemeIzmedjuDrugaDva(zauzece.kraj, pocetak, kraj)
                || jeLiVrijemeIzmedjuDrugaDva(pocetak, zauzece.pocetak, zauzece.kraj) || jeLiVrijemeIzmedjuDrugaDva(kraj, zauzece.pocetak, zauzece.kraj))
                && (!((uporediVremena(zauzece.kraj, pocetak) == 0 && uporediVremena(zauzece.pocetak, zauzece.kraj) <= 0) 
                || (uporediVremena(kraj, zauzece.pocetak) == 0 && uporediVremena(pocetak, kraj) <= 0)));
            });
            if (filtriraniNizVanrednihZauzeca.length != 0) {
                res.set('Content-Type', 'text/plain; charset=utf-8');
                let praviMjesec = mjesec + 1;
                let porukaGreske = "Nije moguće rezervisati salu " + sala + " za navedeni datum " + 
                ((danUMjesecu < 10) ? ("0" + danUMjesecu) : danUMjesecu) + "/" + ((praviMjesec < 10) ? ("0" + praviMjesec) : praviMjesec) + "/" + trenutnaGodina + 
                " i termin od " + pocetak + " do " + kraj + "!";
                res.status(200).send(porukaGreske);
                return;
            }
        }
        else {
            let filtriraniNizVanrednihZauzeca = vanrednaZauzeca.filter(function(zauzece) {
                let nizRazdvojen = zauzece.datum.split(".");
                nizRazdvojen.reverse();
                let noviDatumFormat = nizRazdvojen.join("-");
                let datumZauzeca = new Date(noviDatumFormat);
                let danSedmice = danUSedmici;
                if (danSedmice === 0) danSedmice = 7;
                let danZauzeca = datumZauzeca.getDay();
                if (danZauzeca == 0) danZauzeca = 7;
                let mjesecZauzeca = datumZauzeca.getMonth();
                return danZauzeca == danSedmice && zauzece.naziv === sala 
                && (((mjesecZauzeca === 0 || mjesecZauzeca >= 9 && mjesecZauzeca <= 11) && (mjesec === 0 || mjesec >= 9 && mjesec <= 11)) 
                || ((mjesecZauzeca >= 1 && mjesecZauzeca <= 5) && (mjesec >= 1 && mjesec <= 5))) 
                && (jeLiVrijemeIzmedjuDrugaDva(zauzece.pocetak, pocetak, kraj) || jeLiVrijemeIzmedjuDrugaDva(zauzece.kraj, pocetak, kraj)
                || jeLiVrijemeIzmedjuDrugaDva(pocetak, zauzece.pocetak, zauzece.kraj) || jeLiVrijemeIzmedjuDrugaDva(kraj, zauzece.pocetak, zauzece.kraj))
                && (!((uporediVremena(zauzece.kraj, pocetak) == 0 && uporediVremena(zauzece.pocetak, zauzece.kraj) <= 0) 
                || (uporediVremena(kraj, zauzece.pocetak) == 0 && uporediVremena(pocetak, kraj) <= 0)));
            });
            if (filtriraniNizVanrednihZauzeca.length != 0) {
                res.set('Content-Type', 'text/plain; charset=utf-8');
                let praviMjesec = mjesec + 1;
                let porukaGreske = "Nije moguće rezervisati salu " + sala + " za navedeni datum " + 
                ((danUMjesecu < 10) ? ("0" + danUMjesecu) : danUMjesecu) + "/" + ((praviMjesec < 10) ? ("0" + praviMjesec) : praviMjesec) + "/" + trenutnaGodina + 
                " i termin od " + pocetak + " do " + kraj + "!";
                res.status(200).send(porukaGreske);
                return;
            }
        }
        // Sve uredu, dodajemo novo zauzece
        if (periodicnaRezervacija) {

            if (danUSedmici === 0) danUSedmici = 7;
            danUSedmici--;

            let semestarZaDodati = "zimski";
            if (mjesec >= 1 && mjesec <= 5) semestarZaDodati = "ljetni";

            let objekatNovogPeriodicnogZauzeca = {
                dan: danUSedmici,
                semestar: semestarZaDodati,
                pocetak: pocetak,
                kraj: kraj,
                naziv: sala,
                predavac: "Ime Prezimenkovic"
            };

            vraceniObjekatZauzeca.periodicna.push(objekatNovogPeriodicnogZauzeca);

            let noviStringJson = JSON.stringify(vraceniObjekatZauzeca, null, 4);

            fs.writeFile('zauzeca.json', noviStringJson, function(err) {
                if (err) throw err;
                res.json(vraceniObjekatZauzeca);
            });
        }
        else {
            let praviMjesec = mjesec + 1;
            let stringDatumaZaDodati = ((danUMjesecu < 10) ? ("0" + danUMjesecu) : danUMjesecu) +
             "." + ((praviMjesec < 10) ? ("0" + praviMjesec) : praviMjesec) + "." + new Date().getFullYear();
            
            let objekatNovogVanrednogZauzeca = {
                datum: stringDatumaZaDodati,
                pocetak: pocetak,
                kraj: kraj,
                naziv: sala,
                predavac: "Imenko Prezimenkovic"
            };

            vraceniObjekatZauzeca.vanredna.push(objekatNovogVanrednogZauzeca);

            let noviStringJson = JSON.stringify(vraceniObjekatZauzeca, null, 4);

            fs.writeFile('zauzeca.json', noviStringJson, function(err) {
                if (err) throw err;
                res.json(vraceniObjekatZauzeca);
            });
        }
    });
});

app.post('/slike', function(req, res) {

    let tijelo = req.body;
    let nizVecPostojecihSlika = tijelo['nizVecPostojecihSlika'];

    let objekatZaSlanje = {
        nizSlika: [],
        finalneSlikePoslane: false
    };

    let putanja = __dirname + "/slike";

    fs.readdir(putanja, function(greska, slike) {

        if (greska) return console.error(greska);

        let brojacSlika = 0;
        let nadjenaJosJednaSlika = false;
        for (let i = 0; i < slike.length; i++) {
            let trenutnaSlika = slike[i];
            if (!nizVecPostojecihSlika.includes(trenutnaSlika)) {
                brojacSlika++;
                if (brojacSlika <= 3) objekatZaSlanje.nizSlika.push(trenutnaSlika);
                else if (brojacSlika == 4) {
                    nadjenaJosJednaSlika = true;
                    break;
                }
            }
        }

        if (!nadjenaJosJednaSlika) objekatZaSlanje.finalneSlikePoslane = true;

        res.json(objekatZaSlanje);
    });
});

app.listen(8080);