let Pozivi = (function() {

    function pozoviAjaxUcitajPodatkeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            if (ajax.readyState == 4 && ajax.status == 200) {
                let vraceniJsonZauzeca = ajax.responseText;
                let vraceniObjekatZauzeca = JSON.parse(vraceniJsonZauzeca);
                let nizPeriodicnih = vraceniObjekatZauzeca.periodicna;
                let nizVanrednih = vraceniObjekatZauzeca.vanredna;
                Kalendar.ucitajPodatke(nizPeriodicnih, nizVanrednih);
            }
            if (ajax.readyState == 4 && ajax.status == 404) {
                return "Greska: nepoznat URL!";
            }
        }
        ajax.open("GET", "zauzeca.json", true);
        ajax.send();
    }

    function pozoviAjaxUpisiZauzeceImpl(danUMjesecu, danUSedmici, mjesec, sala, pocetak, kraj, periodicnaRezervacija) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            if (ajax.readyState == 4 && ajax.status == 200) {
                if (ajax.responseText.includes("Nije moguće")) {
                    alert(ajax.responseText);
                }
                else {
                    let vraceniJsonZauzeca = ajax.responseText;
                    let vraceniObjekatZauzeca = JSON.parse(vraceniJsonZauzeca);
                    let nizPeriodicnih = vraceniObjekatZauzeca.periodicna;
                    let nizVanrednih = vraceniObjekatZauzeca.vanredna;
                    Kalendar.ucitajPodatke(nizPeriodicnih, nizVanrednih);
                    trimovanaVrijednostInputaPocetak = inputPocetak.value.trim();
                    trimovanaVrijednostInputaKraj = inputKraj.value.trim();
                    vrijednostDropdownaSale = dropdownListaSala.value;
                    vrijednostCheckboxaPeriodicna = checkboxPeriodicnaRezervacija.checked;
                    if (trimovanaVrijednostInputaPocetak == null || (!trimovanaVrijednostInputaPocetak.length)) return;
                    if (trimovanaVrijednostInputaKraj == null || (!trimovanaVrijednostInputaKraj.length)) return;
                    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, 
                     vrijednostDropdownaSale, trimovanaVrijednostInputaPocetak, trimovanaVrijednostInputaKraj);
                }
            }
            if (ajax.readyState == 4 && ajax.status == 404) {
                return "Greska: nepoznat URL!";
            }
        }
        ajax.open("POST", "zauzeca.json", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        let objekatZaPostRequest = {
            danUMjesecu: danUMjesecu,
            danUSedmici: danUSedmici,
            mjesec: mjesec,
            sala: sala,
            pocetak: pocetak,
            kraj: kraj,
            periodicnaRezervacija: periodicnaRezervacija
        }
        ajax.send(JSON.stringify(objekatZaPostRequest));
    }

    function pozoviAjaxUcitajSlikeImpl(nizVecUcitanih) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            if (ajax.readyState == 4 && ajax.status == 200) {
                let vraceniJsonSlika = ajax.responseText;
                let vraceniObjekatSlika = JSON.parse(vraceniJsonSlika);
                let nizVracenihSlika = vraceniObjekatSlika.nizSlika;
                let sadrzajSaSlikamaRef = document.getElementById("id_sadrzajSaSlikama");
                sadrzajSaSlikamaRef.innerHTML = "";
                for (let i = 0; i < nizVracenihSlika.length; i++) {
                    let trenutnaSlika = nizVracenihSlika[i];
                    nizDosadUcitanihSlika.push(trenutnaSlika);
                    let novaSlikaElement = document.createElement("img");
                    novaSlikaElement.setAttribute("src", trenutnaSlika);
                    novaSlikaElement.setAttribute("alt", "Slika u galeriji");
                    novaSlikaElement.classList.add("slikaUGaleriji");
                    sadrzajSaSlikamaRef.appendChild(novaSlikaElement);
                }
                if (vraceniObjekatSlika.finalneSlikePoslane) dugmeSljedeci.disabled = true;
                else dugmeSljedeci.disabled = false;
            }
            if (ajax.readyState == 4 && ajax.status == 404) {
                return "Greska: nepoznat URL!";
            }
        }
        ajax.open("POST", "slike", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        let objekatZaPostRequest = {
            nizVecPostojecihSlika: nizVecUcitanih
        }
        ajax.send(JSON.stringify(objekatZaPostRequest));
    }

    return {
        pozoviAjaxUcitajPodatke: pozoviAjaxUcitajPodatkeImpl,
        pozoviAjaxUpisiZauzece: pozoviAjaxUpisiZauzeceImpl,
        pozoviAjaxUcitajSlike: pozoviAjaxUcitajSlikeImpl
    }
}());