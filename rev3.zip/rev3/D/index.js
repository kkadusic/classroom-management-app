const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.get("/", function(req, res) {
    opt = { root: __dirname };
    res.sendFile("pocetna.html", opt);
});

app.get("/sale", function(req, res) {
    opt = { root: __dirname };
    res.sendFile("sale.html", opt);
});

app.get("/unos", function(req, res) {
    opt = { root: __dirname };
    res.sendFile("unos.html", opt);
});

app.get("/rezervacija", function(req, res) {
    opt = { root: __dirname };
    res.sendFile("rezervacija.html", opt);
});

app.get("/testoviS2", function(req, res) {
    opt = { root: __dirname };
    res.sendFile("testoviS2.html", opt);
});

app.post("/ucitajpodatke", function(req, res) {
    let data = fs.readFileSync("public/zauzeca.json");
    let parsedData = JSON.parse(data);

    let periodicna = parsedData[0];
    let vanredna = parsedData[1];

    let zaUpisati = [];
    zaUpisati[0] = periodicna;
    zaUpisati[1] = vanredna;
    res.json({ message: "Uspjesno ucitani podaci", data: zaUpisati });
});

app.post("/upis", function(req, res) {
    let data = fs.readFileSync("public/zauzeca.json");
    let parsedData = JSON.parse(data);

    let periodicna = parsedData[0];
    let vanredna = parsedData[1];

    //console.log(parsedData.periodicna[0]);
    //console.log(req.body);
    if (req.body.periodicna) {
        /*res.json({
            message:
                "Treba dodati periodicno zauzece, nije jos implementirano.",
            data: parsedData
        });*/
    } else {
        //Provjera da li je odabrana vanredna sala zauzeta
        //Da li imaju vanredna zauzeca sa tim datumom, vremenom i salom
        for (let i = 0; i < vanredna.length; i++) {
            if (
                vanredna.sala === req.body.sala &&
                vanredna.datum === req.body.datum
            ) {
                let uslov = true;
                let pocetakTrazeni = req.body.pocetak.split(":");
                let krajTrazeni = req.body.kraj.split(":");
                let krajSala = vanredna[i].kraj.split(":");
                let pocetakSala = vanredna[i].pocetak.split(":");
                if (
                    pocetakTrazeni[0] >= krajSala[0] ||
                    krajTrazeni[0] <= pocetakSala[0]
                ) {
                    if (
                        krajTrazeni[0] === pocetakSala[0] &&
                        krajTrazeni[1] > pocetakSala[1]
                    )
                        uslov = true;
                    else if (
                        pocetakTrazeni[0] === krajSala[0] &&
                        pocetakTrazeni[1] < krajSala[1]
                    )
                        uslov = true;
                    else uslov = false;
                }
                if (pocetakTrazeni[0] >= krajTrazeni[0]) {
                    if (
                        pocetakTrazeni[0] === krajTrazeni[0] &&
                        pocetakTrazeni[1] > krajTrazeni[1]
                    ) {
                        uslov = false;
                    }
                }
                if (uslov) {
                    res.json({
                        message: "Sala je vec zauzeta",
                        data: parsedData
                    });
                    return;
                }
            }
        }
        //Res.send treba biti ovde
        //Da li imaju periodicna zauzeca u tom semestru, vremenu i sali
    }

    if (req.body.periodicna) {
        let temp = {
            dan: req.body.dan,
            semestar: req.body.semestar,
            pocetak: req.body.pocetak,
            kraj: req.body.kraj,
            naziv: req.body.sala,
            predavac: "Predavac"
        };
        periodicna[periodicna.length] = temp;
    } else {
        let temp = {
            datum: req.body.datum,
            pocetak: req.body.pocetak,
            kraj: req.body.kraj,
            naziv: req.body.sala,
            predavac: "Predavac"
        };
        vanredna[vanredna.length] = temp;
    }

    let zaUpisati = [];
    zaUpisati[0] = periodicna;
    zaUpisati[1] = vanredna;
    let finalData = JSON.stringify(zaUpisati, null, 2);
    fs.writeFile("public/zauzeca.json", finalData, finished);

    function finished(err) {
        console.log(err);
    }

    res.json({ message: "Uspjesno dodana sala", data: zaUpisati });
});

app.post("/dajslike", function(req, res) {
    let data = fs.readFileSync("public/linkoviSlika.json");
    let parsedData = JSON.parse(data);

    let finalData = [];
    let temp = 0,
        broj = req.body.redniBroj;
    let counter = 0;
    for (let i = 0; i < parsedData.length; i++) {
        if (i === broj) {
            finalData[temp] = parsedData[i];
            counter++;
            if (temp < 2) {
                temp++;
                broj++;
            }
        }
    }
    console.log("Broj vracenih slika: ", counter);
    res.json({
        message: "Vacena poruka sa servera",
        data: finalData,
        brojVracenihSlika: counter
    });
});

app.listen(8080);
