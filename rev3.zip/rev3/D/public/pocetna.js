let Pocetna = (function() {
    let ucitatiSLikeOd = 0;
    let maxUcitano = 0;
    let vraceniObjekti = [];
    let ucitaneSveSlike = false;
    let trenutnoVraceniObjekti = [];
    let grupeSlike = [];
    let trenutnoSePrikazujeGrupa = 0;

    function ucitajSLikeImpl() {
        ucitatiSLikeOd = 0;
        Pozivi.dajSljedeceSlike(ucitatiSLikeOd);
        vraceniObjekti = Pozivi.proslijediVraceneObjekte();
        setTimeout(function() {
            trenutnoVraceniObjekti = Pozivi.proslijediTrenutnoVraceneObjekte();
            grupeSlike[grupeSlike.length] = {
                grupa: grupeSlike.length,
                slike: trenutnoVraceniObjekti
            };
            let brojVracenihSlika = Pozivi.proslijediBrojVracenihSlika();
            let slike = document.getElementsByClassName("slike");
            if (brojVracenihSlika < 3) {
                ucitaneSveSlike = true;
                document.getElementById("sljedeci").disabled = true;
            }

            let temp = 0,
                broj = ucitatiSLikeOd;
            for (let i = 0; i < brojVracenihSlika; i++) {
                if (broj === i) {
                    slike[temp].src = vraceniObjekti[broj].url;
                    if (temp < 2) {
                        temp++;
                        broj++;
                        ucitatiSLikeOd++;
                        maxUcitano++;
                    }
                }
            }

            ucitatiSLikeOd++;
        }, 200);

        document.getElementById("prethodni").disabled = true;
        document
            .getElementById("prethodni")
            .addEventListener("click", function() {
                ucitajPrethodneSlikeImpl();
            });

        document
            .getElementById("sljedeci")
            .addEventListener("click", function() {
                ucitajSljedeceSLikeImpl();
            });
    }

    function ucitajSljedeceSLikeImpl() {
        document.getElementById("prethodni").disabled = false;
        trenutnoSePrikazujeGrupa++;
        let tmp = maxUcitano + 1;
        if (
            tmp === ucitatiSLikeOd &&
            trenutnoSePrikazujeGrupa > grupeSlike[grupeSlike.length - 1].grupa
        ) {
            let slike = document.getElementsByClassName("slike");
            slike[0].src = "";
            slike[1].src = "";
            slike[2].src = "";
            Pozivi.dajSljedeceSlike(ucitatiSLikeOd);
            setTimeout(function() {
                trenutnoVraceniObjekti = Pozivi.proslijediTrenutnoVraceneObjekte();
                grupeSlike[grupeSlike.length] = {
                    grupa: grupeSlike.length,
                    slike: trenutnoVraceniObjekti
                };
                let brojVracenihSlika = Pozivi.proslijediBrojVracenihSlika();
                if (brojVracenihSlika < 3) {
                    ucitaneSveSlike = true;
                    document.getElementById("sljedeci").disabled = true;

                    if (brojVracenihSlika === 1) {
                        slike[1].style.display = "none";
                        slike[2].style.display = "none";
                    } else if (brojVracenihSlika === 2) {
                        slike[2].style.display = "none";
                    }
                }
                for (let i = 0; i < brojVracenihSlika; i++) {
                    slike[i].style.display = "block";
                    slike[i].src = vraceniObjekti[maxUcitano + 1].url;
                    maxUcitano++;
                    ucitatiSLikeOd++;
                }
            }, 200);
        } else {
            let slike = document.getElementsByClassName("slike");
            let zaPrikazati = [];
            slike[0].src = "";
            slike[1].src = "";
            slike[2].src = "";

            for (let i = 0; i < grupeSlike.length; i++) {
                if (trenutnoSePrikazujeGrupa === grupeSlike[i].grupa) {
                    zaPrikazati = grupeSlike[i].slike;
                }
            }
            for (let i = 0; i < zaPrikazati.length; i++) {
                slike[i].style.display = "block";
                slike[i].src = zaPrikazati[i].url;
            }
            if (zaPrikazati.length < 3) {
                document.getElementById("sljedeci").disabled = true;

                if (zaPrikazati.length === 1) {
                    slike[1].style.display = "none";
                    slike[2].style.display = "none";
                } else if (zaPrikazati.length === 2) {
                    slike[2].style.display = "none";
                }
            }
        }
    }

    function ucitajPrethodneSlikeImpl() {
        document.getElementById("sljedeci").disabled = false;
        let slike = document.getElementsByClassName("slike");
        trenutnoSePrikazujeGrupa--;
        let zaPrikazati = [];
        slike[0].src = "";
        slike[1].src = "";
        slike[2].src = "";
        for (let i = 0; i < grupeSlike.length; i++) {
            if (trenutnoSePrikazujeGrupa === grupeSlike[i].grupa) {
                zaPrikazati = grupeSlike[i].slike;
            }
        }
        for (let i = 0; i < zaPrikazati.length; i++) {
            slike[i].style.display = "block";
            slike[i].src = zaPrikazati[i].url;
        }

        if (trenutnoSePrikazujeGrupa === 0)
            document.getElementById("prethodni").disabled = true;
    }

    return {
        ucitajSLike: ucitajSLikeImpl,
        ucitajPrethodneSlike: ucitajPrethodneSlikeImpl,
        ucitajSljedeceSLike: ucitajSljedeceSLikeImpl
    };
})();
