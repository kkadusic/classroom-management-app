let Pozivi = (function() {
    //
    //ovdje idu privatni atributi
    //

    let vraceniObjekti = [];
    let trenutniVraceniObjekti = [];
    let brojVracenihSlika = 0;

    function ucitajPodatkeImpl() {
        /*
        $.getJSON("zauzeca.json", function(data) {
            console.log(data);
        });
        */
        /*
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            console.log(this.readyState);
            console.log(this.status);
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText);
                console.log("okej");
            }
        };
        xhttp.open("GET", "zauzeca.json", true);
        xhttp.send();
        */

        let periodicna = [];
        let vanredna = [];
        $.ajax({
            url: "zauzeca.json",
            dataType: "json",
            type: "get",
            cache: false,
            success: function(data) {
                $(data[0]).each(function(index, value) {
                    periodicna[index] = value;
                });
                $(data[1]).each(function(index, value) {
                    vanredna[index] = value;
                });
            }
        });
        Kalendar.ucitajPodatke(periodicna, vanredna);
    }

    function upisiZauzeceImpl(Kliknuto) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
                let parsedData = JSON.parse(ajax.response);
                Kalendar.ucitajPodatke(parsedData.data[0], parsedData.data[1]);
                Kalendar.iscrtajKalendar(
                    document.getElementById("kalendar"),
                    Kliknuto.mjesec
                );
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("Error");
        };
        ajax.open("POST", "upis", true);
        ajax.setRequestHeader("Content-Type", "application/json");

        ajax.send(
            JSON.stringify({
                dan: Kliknuto.dan,
                datum: Kliknuto.datum,
                pocetak: Kliknuto.pocetak,
                kraj: Kliknuto.kraj,
                sala: Kliknuto.sala,
                periodicna: Kliknuto.periodicna,
                mjesec: Kliknuto.mjesec,
                semestar: Kliknuto.semestar
            })
        );
    }

    function dajSljedeceSlikeImpl(redniBroj) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {
            // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
                let parsedData = JSON.parse(ajax.response);
                for (let i = 0; i < parsedData.data.length; i++) {
                    vraceniObjekti[vraceniObjekti.length] = parsedData.data[i];
                }
                trenutniVraceniObjekti = parsedData.data;
                brojVracenihSlika = parsedData.brojVracenihSlika;
                console.log(parsedData);
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("Error");
        };
        ajax.open("POST", "dajslike", true);
        ajax.setRequestHeader("Content-Type", "application/json");

        ajax.send(
            JSON.stringify({
                redniBroj: redniBroj
            })
        );
        proslijediVraceneObjekteImpl();
    }

    function proslijediVraceneObjekteImpl() {
        return vraceniObjekti;
    }

    function proslijediBrojVracenihSlikaImpl() {
        return brojVracenihSlika;
    }

    function proslijediTrenutnoVraceneObjekteImpl() {
        return trenutniVraceniObjekti;
    }

    return {
        ucitajPodatke: ucitajPodatkeImpl,
        upisiZauzece: upisiZauzeceImpl,
        dajSljedeceSlike: dajSljedeceSlikeImpl,
        proslijediVraceneObjekte: proslijediVraceneObjekteImpl,
        proslijediBrojVracenihSlika: proslijediBrojVracenihSlikaImpl,
        proslijediTrenutnoVraceneObjekte: proslijediTrenutnoVraceneObjekteImpl
    };
})();
