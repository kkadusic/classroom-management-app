Pozivi.ucitajPodatke();

let odabirSale = function() {
    let c = confirm("Da li zelite zauzeti salu?");
    if (c === true) alert("Sala je sacuvana");
    else alert("Sala nije sacuvana");
};

let Kliknuto = {
    dan: "dan",
    datum: "datum",
    pocetak: "pocetak",
    kraj: "kraj",
    sala: "sala",
    periodicna: "da",
    mjesec: "mjesec",
    semestar: "semestar"
};

function postavi() {
    let dani = document.getElementsByClassName("dani");
    for (let i = 0; i < dani.length; i++) {
        (function(index) {
            dani[index].addEventListener("click", function() {
                Kliknuto.sala = document.getElementById("sale").options[
                    document.getElementById("sale").selectedIndex
                ].value;

                let klase = dani[index].className;
                if (klase.search("zauzeta") != -1) return;

                Kliknuto.pocetak = document.getElementById("pocetak").value;
                Kliknuto.kraj = document.getElementById("kraj").value;
                Kliknuto.periodicna = document.getElementById(
                    "checkbox1"
                ).checked;

                Kliknuto.dan = index % 7;

                Kliknuto.mjesec = vratiMjesec(
                    document.getElementById("kalendar").children[0].textContent
                );
                Kliknuto.semestar = vratiSemestar(Kliknuto.mjesec);
                let godina = new Date().getFullYear();
                let mj = Kliknuto.mjesec + 1;
                Kliknuto.datum =
                    dani[index].children[0].textContent +
                    "." +
                    mj +
                    "." +
                    godina;
                console.log("Informacije o kliknutom: ");
                console.log(Kliknuto);

                let dodatak = " neperiodicno ";
                if (Kliknuto.periodicna) dodatak = " periodicno ";

                //Confirm
                let c = confirm(
                    "Da li zelite zauzeti salu " +
                        Kliknuto.sala +
                        " u terminu od " +
                        Kliknuto.pocetak +
                        " do " +
                        Kliknuto.kraj +
                        dodatak
                );
                if (c === true) {
                    Pozivi.upisiZauzece(Kliknuto);
                    Kalendar.iscrtajKalendar(
                        document.getElementById("kalendar"),
                        Kliknuto.mjesec
                    );
                    alert("Sala je sacuvana");
                } else alert("Sala nije sacuvana");
            });
        })(i);
    }
}

function vratiMjesec(mjesec) {
    if (mjesec === "Januar") return 0;
    else if (mjesec === "Februar") return 1;
    else if (mjesec === "Mart") return 2;
    else if (mjesec === "April") return 3;
    else if (mjesec === "Maj") return 4;
    else if (mjesec === "Juni") return 5;
    else if (mjesec === "Juli") return 6;
    else if (mjesec === "August") return 7;
    else if (mjesec === "Septembar") return 8;
    else if (mjesec === "Oktobar") return 9;
    else if (mjesec === "Novembar") return 10;
    else if (mjesec === "Decembar") return 11;
}

function vratiSemestar(mjesec) {
    if (mjesec === 0 || mjesec >= 9) return "zimski";
    else if (mjesec > 0 && mjesec < 6) return "ljetni";
    else return "pauza";
}
