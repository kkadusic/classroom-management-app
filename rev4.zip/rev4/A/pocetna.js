//zadatak 3
function ucitavanjeSlika(){
    Pozivi.ucitavanjeSlika();
}

function ucitajSljedece(){
    Pozivi.ucitavanjeSljedecihSlika();
    document.getElementById("prethodne").disabled  = false;
    
}

function ucitajPrethodne(){
    Pozivi.ucitavanjePrethodnihSlika();
    document.getElementById("sljedece").disabled = false;
}

//zadatak 4
function vratiBrojPosjeta(){
    Pozivi.brojPosjeta();
}
