
const fs = require('fs'),
express = require('express'),
bodyParser = require('body-parser'),
path = require('path'),
pageSetupData = require('./modules/core/server/clientPageSetup'),
rezervacija = require('./modules/rezervacija/server/rezervacija'),
pocetna = require('./modules/pocetna/server/pocetna'),
dbSetup = require('./modules/core/server/database/dbSetup'),
osobaUpiti = require('./modules/osoba/server/upiti.servis'),
saleUpiti = require('./modules/sale/server/upiti.servis'),
rezervacijeUpiti = require('./modules/rezervacija/server/upiti.servis'),
osoblje = require('./modules/osoba/server/osoba')
rute = require('./rute'),
opts = require('optimist').argv,
app = express();

function registerStaticRoute(route, path) {
    app.get(route, function (req, res) {
        res.sendFile(path);
    });
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', express.static(path.join(__dirname, 'public')));

console.info("Registrovanje ruta za assete i stranice")
pageSetupData.pageMappings.forEach((page) => {
    const modulePath = `${__dirname}/modules${page.modulePath}/client`;
    fs.readdirSync(modulePath).forEach((moduleFile) => {
        const extension = path.extname(moduleFile);
        const isAsset = page.assetTypes.find(s => `.${s}` === extension) !== undefined;
        if (isAsset) {
            const route = `/${moduleFile}`;
            const assetPath = path.join(modulePath, moduleFile);
            console.info("Registrovan asset: ", moduleFile)
            registerStaticRoute(route, assetPath);
        }
    })

    // Ruta za html fajl
    if (page.id != null) {
        const pageRoute = `/${page.id}`;
        const pagePath = `${__dirname}/modules${page.path}`;
        console.info("Registrovana stranica: ", pageRoute);
        registerStaticRoute(pageRoute, pagePath);
    }
});

app.get(rute.rezervacije.bazna, function(req,res){
    rezervacija.dajTermine()
        .then((data) => {
            res.json(data);
    });
});
app.post(rute.rezervacije.bazna, rezervacija.rezervisiTermin);

// Rute vezane za osoblje
app.get(rute.osoblje.bazna, function(req,res){
    osobaUpiti.dajOsoblje()
        .then((data) => {
            res.json(data)
        });
});
app.post(rute.osoblje.bazna, function(req,res){
    const osoba = { ime: req.body.ime, prezime: req.body.prezime, uloga: req.body.uloga };
    // Provjera podataka
    if (!osoba.ime || !osoba.prezime || !osoba.uloga) {
        return res.status(400).json({
            message: 'Neispravni podaci poslati'
        })
    }
    osobaUpiti.dodajOsobu(osoba)
        .then((data) => {
            res.json(data);
        });
});
app.get(rute.osoblje.zauzeca, function(req,res){
    const datum = req.query.datum;
    osoblje.dajZauzecaOsobljaNaDatum(datum)
        .then((data) => {
            res.json(data);
        })
        .catch((err) => {
            return res.status(400).json({
                message: err
            })
        })

});

// Rute vezane za salu
app.get(rute.sale.bazna, function(req,res){
    saleUpiti.dajSale()
        .then((data) => res.json(data));
});

// Rute vezane za dobavljanje slika
app.get(rute.slike.bazna, function(req, res) {
    res.send(pocetna.dajPaginacijuSlika(req));
});

const port = opts.port || 8080;
app.listen(port, () => {
    dbSetup.sinhronizacija();
    console.log(`Aplikacija pokrenuta na ${port}!`)
});

module.exports = app;