
// Pozivi modul 
let Pozivi = (function () {
    const api = {
        rezervacije: '/rezervacije',
        slike: '/slike',
        osoblje: '/osoblje',
        sale: '/sale'
    }
    const contentJson = {
        key: 'Content-Type',
        value: 'application/json;charset=UTF-8'
    }
    function ucitajRezervacije(callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            }
        };
        xhttp.open("GET", api.rezervacije, true);
        xhttp.send();
    }

    function spasiRezervaciju(data, callback, errorCallback) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            } else if(this.readyState == 4  && this.status >= 400) {
                errorCallback(JSON.parse(this.responseText));
            }
        };
        xhttp.open("POST", api.rezervacije, true);
        xhttp.setRequestHeader(contentJson.key, contentJson.value)
        xhttp.send(JSON.stringify(data));
    }

    function dajStranicuSlika(data, callback, errorCallback) {
        var xhttp = new XMLHttpRequest();
        var params = `page=${data.page}&limit=${data.limit}`;
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            } else if(this.readyState == 4  && this.status >= 400) {
                errorCallback(this.responseText);
            }
        };
        xhttp.open("GET", `${api.slike}?${params}`, true);
        xhttp.setRequestHeader(contentJson.key, contentJson.value)
        xhttp.send(JSON.stringify(data));
    }

    function ucitajOsobe(callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            }
        };
        xhttp.open("GET", api.osoblje, true);
        xhttp.send();
    }

    function ucitajSale(callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            }
        };
        xhttp.open("GET", api.sale, true);
        xhttp.send();
    }

    function dajZauzecaOsoblja(datum, callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                callback(JSON.parse(this.responseText));
            }
        };
        xhttp.open("GET", `${api.osoblje}/zauzeca?datum=${datum}`, true);
        xhttp.send(JSON.stringify({
            datum
        }));
    }

    return {
        ucitajRezervacije,
        dajStranicuSlika,
        dajZauzecaOsoblja,
        ucitajOsobe,
        ucitajSale,

        spasiRezervaciju
    }
}());

