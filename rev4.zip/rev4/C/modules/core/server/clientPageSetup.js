exports.assetTypes = [
    "js", "css"
]

exports.pageMappings = [
    {
        "id": "",
        "modulePath": "/pocetna",
        "assetName": "pocetna",
        "path": "/pocetna/client/pocetna.html",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "id": "osoba.html",    
        "modulePath": "/osoba",
        "assetName": "osoba",
        "path": "/osoba/client/osoba.html",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "id": "rezervacija.html",
        "modulePath": "/rezervacija",
        "assetName": "rezervacija",
        "path": "/rezervacija/client/rezervacija.html",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "id": "sale.html",
        "modulePath": "/sale",
        "assetName": "sale",
        "path": "/sale/client/sale.html",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "id": "unos.html",
        "modulePath": "/unos",
        "assetName": "unos",
        "path": "/unos/client/unos.html",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "assetName": "kalendar",
        "modulePath": "/kalendar",
        "assetTypes": [
            "js", "css"
        ]
    },
    {
        "assetName": "core",
        "modulePath": "/core",
        "assetTypes": [
            "js", "css"
        ]
    }
]
 