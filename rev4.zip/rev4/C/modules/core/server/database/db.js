const Sequelize = require("sequelize"),
path = require('path'),
veze = require('./relationship'),
config = require('config');

const baseFolderOffsetPath = '../../../../';
function getBaseModuleOffsetPath(path) {
    return baseFolderOffsetPath + path;
}

const sequelize = new Sequelize(config.db.name, config.db.username,  config.db.password, {
    host: config.db.host,
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    },
    logging: false
 });
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(path.join(__dirname, getBaseModuleOffsetPath('models/osoblje.js')));
db.rezervacija = sequelize.import(path.join(__dirname,getBaseModuleOffsetPath('models/rezervacija.js')));
db.sala = sequelize.import(path.join(__dirname, getBaseModuleOffsetPath('models/sala.js')));
db.termin = sequelize.import(path.join(__dirname, getBaseModuleOffsetPath('models/termin.js')));

veze.inicializacijaVeza(db);

module.exports=db;