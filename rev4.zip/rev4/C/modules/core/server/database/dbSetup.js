const db = require('./db.js');

function sinhronizacijaBezInicijalizacije() {
    return db.sequelize.sync({force: true});
}

function sinhronizacija(){ 
    sinhronizacijaBezInicijalizacije()
        .then(function(){
        inicializacija()
            .then(function(){
                console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        });
    });
}

function inicializacija(){
    var osobljePromisea=[];
    var salePromisea=[];
    var terminiPromisea=[];
    var rezervacijePromisea=[];
    return new Promise(function(resolve,reject){
        osobljePromisea.push(db.osoblje.create({ime:'Neko', prezime: 'Nekić', 
            uloga: 'profesor'}));
        osobljePromisea.push(db.osoblje.create({ime:'Drugi', prezime: 'Neko', 
            uloga: 'asistent'}));
        osobljePromisea.push(db.osoblje.create({ime:'Test', prezime: 'Test', 
            uloga: 'asistent'}));

        Promise.all(osobljePromisea)
            .then(function(osoblje) {

                terminiPromisea.push(
                    db.termin.create({redovni:false, dan: null, datum: '01.01.2020', 
                        semestar: null, pocetak: '12:00', kraj: '13:00'}));
                terminiPromisea.push(
                    db.termin.create({redovni: true, dan: 0, datum: null, 
                    semestar: 'zimski', pocetak: '13:00', kraj: '14:00'}));
                Promise.all(terminiPromisea)
                    .then((termini) => {
                    var neko = osoblje.find(function(a){return a.ime === 'Neko'});
                    var drugi = osoblje.find(function(a){return a.ime==='Drugi'});
                    var test = osoblje.find(function(a){return a.ime==='Test'});
        
                    salePromisea.push(
                        db.sala.create({naziv: '1-11', zaduzenaOsoba: neko.id })
                    );
                    salePromisea.push(
                        db.sala.create({naziv:'1-15', zaduzenaOsoba: drugi.id })
                    );

                    Promise.all(salePromisea)
                    .then(function(sale){
                        var sala111 = sale.find((k) => k.naziv==='1-11' );
                        var termin1 = termini.find((k) => k.id === 1);
                        var termin2 = termini.find((k) => k.id === 2);
                        rezervacijePromisea.push(
                            db.rezervacija.create({ termin: termin1.id, sala: sala111.id, osoba: neko.id })
                        );
                        rezervacijePromisea.push(
                            db.rezervacija.create({termin: termin2.id, sala: sala111.id, osoba: test.id })
                        );
                        Promise.all(rezervacijePromisea)
                        .then(function(b){resolve(b);})
                        .catch(function(err){console.log("Rezervacija greska "+err);});
                }).catch(function(err){console.log("Sale greska "+err);});
            }).catch(function(err){console.log("Termini greska " + err);}); 
        }).catch(function(err){console.log("Osoblje greska " + err);});   
    });
}

exports.sinhronizacija = sinhronizacija;
exports.inicializacija = inicializacija;
exports.sinhronizacijaBezInicijalizacije = sinhronizacijaBezInicijalizacije;