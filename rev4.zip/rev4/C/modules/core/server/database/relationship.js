exports.inicializacijaVeza = function inicializacijaVeza(db){
    // Ovaj se alijas asocijacija koristi u query unutar sale
    db.sala.belongsTo(db.osoblje, {as: 'osobaZaSalu', foreignKey: 'zaduzenaOsoba' });
    // Ovaj se alijas asocijacija koristi u query unutar rezervacije
    db.rezervacija.belongsTo(db.termin, {as: 'rezervisaniTermin', foreignKey: 'termin'});

    db.osoblje.hasMany(db.rezervacija, { as:'osobljeRezervacije' });
    // Ovaj se alijas  asocijacija koristi u query unutar rezervacije
    db.rezervacija.belongsTo(db.osoblje, { as:'rezervacijaOsoblja', foreignKey: 'osoba' });

    db.sala.hasMany(db.rezervacija,{ as:'rezervacijeSale' });
    // Ovaj se alijas  asocijacija koristi u query unutar rezervacije
    db.rezervacija.belongsTo(db.sala,{ as:'salaRezervisana', foreignKey: 'sala' });
}