
// Pomocne funkcije 

let KalendarPomocne = (function () {
    this.mapiranjeMjeseca = {
        "January": {
            "bs": "Januar"
        },
        "February": {
            "bs": "Februar"
        },
        "March": {
            "bs": "Mart"
        },
        "April": {
            "bs": "April"
        },
        "May": {
            "bs": "Maj"
        },
        "June": {
            "bs": "Juni"
        },
        "July": {
            "bs": "Juli"
        },
        "August": {
            "bs": "August"
        },
        "September": {
            "bs": "Septembar"
        },
        "October": {
            "bs": "Oktobar"
        },
        "November": {
            "bs": "Novembar"
        },
        "December": {
            "bs": "Decembar"
        }
    };

    this.zimskiSemestarMjeseci = [
        10, 11, 12, 1, 2
    ];

    this.ljetniSemestarMjeseci = [
        2, 3, 4, 5, 6
    ];
    this.brojDanaUSedmici = 7;
    this.prviDanUSedmici = 1;
    this.opisZaglavljaDana = ["PON", "UTO", "SRI", "ČET", "PET", "SUB", "NED"];
    this.danasnjiDatum = new Date();
    this.semestarLjetni = "ljetni";
    this.semestarZimski = "zimski";

    dajMjeseceSemestra = (semestar) => {
        // ljetni ili zimski
        switch (semestar) {
            case this.semestarLjetni: {
                return this.ljetniSemestarMjeseci;
            }
            case this.semestarZimski: {
                return this.zimskiSemestarMjeseci;
            }
        }
    }

    daLiJeMjesecUDatomSemestru = (semestar, mjesec) => {
        const mjeseci = this.dajMjeseceSemestra(semestar);
        if (!mjeseci) {
            return false;
        }
        return mjeseci.indexOf(mjesec) > -1;
    }

    daLiJeMjesecUSemestru = (mjesec) => {
        const daLiJeLjetni = this.ljetniSemestarMjeseci.indexOf(mjesec) > -1;
        const daLiJeZimski = this.zimskiSemestarMjeseci.indexOf(mjesec) > -1;

        return daLiJeLjetni || daLiJeZimski;
    }

    dajSemestarZaMjesec = (mjesec) => {
        const daLiJeLjetni = this.ljetniSemestarMjeseci.indexOf(mjesec) > -1;
        if (daLiJeLjetni) {
            return this.semestarLjetni;
        }

        const daLiJeZimski = this.zimskiSemestarMjeseci.indexOf(mjesec) > -1;
        if (daLiJeZimski) {
            return this.semestarZimski;
        } 
        return null;
    }

    dajMapiranjeMjeseca = () => {
        return this.mapiranjeMjeseca;
    }

    dajDatumIzMjesecaIDana = (mjesec, dan) => {
        const datum = new Date(new Date().getFullYear(), mjesec, dan);
        return datum;
    }

    // https://stackoverflow.com/questions/13571700/get-first-and-last-date-of-current-month-with-javascript-or-jquery
    dajPocetakIKrajMjeseca = (datum) => {
        const godina = datum.getFullYear(), mjesec = datum.getMonth();
        const prviDan = new Date(godina, mjesec, 1);
        const zadnjiDan = new Date(godina, dajNormalizovaniMjesec(mjesec), 0);
        return {
            prvi: prviDan,
            zadnji: zadnjiDan
        }
    }

    dajNazivMjeseca = (datum) => {
        var zeljenaLokalizacija = "bs", defaultLokalizacije = "en",
            defaultnoImeMjeseca = datum.toLocaleString(defaultLokalizacije, { month: "long" }),
            imeMjeseca = this.mapiranjeMjeseca[defaultnoImeMjeseca][zeljenaLokalizacija];
        return imeMjeseca;
    }

    dajConstante = () => {
        return {
            "status": "status",
            "slobodna": "slobodna",
        }
    }

    daLiJeDatumIsti = (datum1, datum2) => {
        return datum1.getFullYear() === datum2.getFullYear() && datum1.getDate() === datum2.getDate()
            && datum1.getMonth() === datum2.getMonth();
    }

    dajNormalizovaniMjesec = (mjesec) => {
        return mjesec + 1;
    }

    function tekstUDatum(_date, _format, _delimiter) {
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf("mm");
        var dayIndex = formatItems.indexOf("dd");
        var yearIndex = formatItems.indexOf("yyyy");
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }

    return {
        dajPocetakIKrajMjeseca,
        dajNazivMjeseca,
        dajMjeseceSemestra,
        daLiJeMjesecUSemestru,
        dajDatumIzMjesecaIDana,

        brojDanaUSedmici,
        prviDanUSedmici,
        opisZaglavljaDana,
        danasnjiDatum,
        daLiJeDatumIsti,
        tekstUDatum,
        daLiJeMjesecUDatomSemestru,
        dajSemestarZaMjesec,
        dajNormalizovaniMjesec
    }
}());
