let KalendarPrikaz = (function() {
    this.trenutniDatum = new Date();

    postaviMjesec = (mjesec) => {
        this.trenutniDatum = new Date(this.opisGodine(), mjesec);
    }

    postaviTrenutni = (datum) => this.trenutniDatum = datum;

    opisMjeseca = () => KalendarPomocne.dajNazivMjeseca(this.trenutniDatum);
    opisGodine = () => this.trenutniDatum.getFullYear();

    dajTrenutniDatum = () => this.trenutniDatum;
    dajTrenutniMjesec = () => this.trenutniDatum.getMonth();


    postaviOpisMjeseca = () => {
        const mjesecOpis = document.getElementById("opisMjeseca");
        mjesecOpis.textContent = this.opisMjeseca();
    }

    postaviOpisGodine = () => {
        const godinaOpis = document.getElementById("opisGodine");
        godinaOpis.textContent = this.opisGodine();
    }

    dajBrojDana = ({ zadnji, prviDanUMjesecu }) => {
        let brojDana = zadnji.getDate();
        const pocetakOffset = (prviDanUMjesecu - KalendarPomocne.prviDanUSedmici);
        const krajOffset = (zadnji.getDay() - KalendarPomocne.brojDanaUSedmici);
        const daniOffset = pocetakOffset - krajOffset;
        brojDana += daniOffset;
        return brojDana;
    }

    // Vraca dane od 0 do 6, Pon do Ned
    dajNormalizovaniDanSedmice = (prvi) =>{
        let prviDanUMjesecu = prvi.getDay();
        // getDay vraca 0 kao Nedjelju sto smatra prvim danom tako da moram za taj slucaj prilagoditi logiku
        if (prviDanUMjesecu <= 0) {
            prviDanUMjesecu = KalendarPomocne.brojDanaUSedmici;
        }
        return prviDanUMjesecu - 1;
    }

    dodajDaneKalendara = (tabelaKalendar = document.getElementById("tabelaKalendar")) => {
        // Brisanje tabele i dodavanje zaglavlja
        tabelaKalendar.innerHTML = "";
        const zaglavlje = this.dajZaglavljeDana();
        tabelaKalendar.appendChild(zaglavlje);
    
        // Kreiranje logike za pracenje dana
        const { prvi, zadnji } = KalendarPomocne.dajPocetakIKrajMjeseca(this.trenutniDatum);

        const normalizovaniPrviDanUMjesecu = this.dajNormalizovaniDanSedmice(prvi);
        // Jer ova normalizovani vraca od 0 do 6, a nama treba 1 do 7 dani
        let prviDanUMjesecu = (normalizovaniPrviDanUMjesecu + 1);
        let brojDana = this.dajBrojDana({zadnji, prviDanUMjesecu});

        const krajOffset = (zadnji.getDay() - KalendarPomocne.brojDanaUSedmici);
        const zadnjiDaniUMjesecu = brojDana + krajOffset;
        // Dodavanje dana i sedmica u kalendar
        let redSedmice = this.dajSedmicuUKalendaru();
        for (let i = 1;i <= brojDana;i++) { 
            let brojacDana = i - (normalizovaniPrviDanUMjesecu);
    
            const td = dajKolonuUKalendaru(i, brojacDana, prviDanUMjesecu, zadnjiDaniUMjesecu);
            redSedmice.appendChild(td);
        
            // Ako smo dosli do kraja sedmice dodaj novi red kao sedmicu
            if (i % KalendarPomocne.brojDanaUSedmici === 0) {
                if (i > KalendarPomocne.prviDanUSedmici) {
                    tabelaKalendar.appendChild(redSedmice);
                    redSedmice = this.dajSedmicuUKalendaru();
                }
            }
        }
    }

    dajKolonuUKalendaru = (iterator, brojacDana, prviDanUMjesecu, zadnjiDaniUMjesecu) => {
        const td = document.createElement("td");
        const mjesec  = this.dajTrenutniMjesec();
        // Ide se od prvog dana u mjesecu do zadnjeg i dodaju elementi
        if (this.daLiJeDanUTrenutnomMjesecu(iterator, prviDanUMjesecu, zadnjiDaniUMjesecu)) {

            const brojDana = document.createElement("p");
            brojDana.classList += "dan";
            brojDana.textContent = brojacDana;

            td.appendChild(brojDana);
            const statusSale = document.createElement("p");
            statusSale.classList += "status";
            statusSale.classList += " slobodna";

            td.appendChild(statusSale);
            td.classList += "danKolona danKolonaOverlay okvir";
            // Mjesec u Date objektu je 0 baziran
            td.addEventListener('click', Rezervacija.rezervisiNaKlikEvent);
            const id = this.dajIdKoloneUKalendaru(brojacDana, mjesec + 1, this.opisGodine());
            td.id = id;
        }
    
        return td;
    }

    dajIdKoloneUKalendaru = (brojacDana, mjesec, godina) => {
        const brojacDanaPadded = brojacDana >= 10 ? brojacDana: "0" + brojacDana;
        const mjesecPadded = mjesec >= 10 ? mjesec : "0" + mjesec;
        return `${brojacDanaPadded}.${mjesecPadded}.${godina}`
    }

    daLiJeDanUTrenutnomMjesecu = (iterator, prviDanUMjesecu, zadnjiDaniUMjesecu) => {
        return iterator >= prviDanUMjesecu && iterator <= (zadnjiDaniUMjesecu);
    }
    
    dajSedmicuUKalendaru = () => {
        const sedmica = document.createElement("tr");
        sedmica.classList += "sedmica";
        return sedmica;
    }
    
    dajZaglavljeDana = () => {
        const zaglavlje = document.createElement("tr");
        zaglavlje.classList += "daniOpis";
        KalendarPomocne.opisZaglavljaDana.forEach(dan => {
            zaglavlje.appendChild(this.dajOpisDanaKolonu(dan));
        })
        return zaglavlje;
    }
    
    dajOpisDanaKolonu = (dan) => {
        const opisDana = document.createElement("th");
        opisDana.classList += "okvir";
        opisDana.textContent = dan;
        return opisDana;
    }

    obojiZauzeca = (kalendarRef, mjesec, sala, vrijemePocetka, vrijemeKraja, osoba = null) => {
        if (mjesec < 0 || mjesec > 11) {
            return;
        }
        
        this.postaviMjesec(mjesec);
        const zauzetiDatumi = Kalendar.dajZauzeteDatume(sala, vrijemePocetka, vrijemeKraja, osoba);
        zauzetiDatumi.forEach((datum) => {
            const idKolone = this.dajIdKoloneUKalendaru(datum.getDate(), datum.getMonth() + 1, datum.getFullYear())
            const element = kalendarRef.querySelector(`[id='${idKolone}']`);
            if (element) {
                const statusKolona = element.querySelector('.status');
                if (statusKolona) {
                    statusKolona.classList = "status zauzeta";
                }
            }
        });
    }

    return {
        postaviMjesec,
        opisMjeseca,
        opisGodine,
        postaviOpisMjeseca,
        postaviOpisGodine,
        postaviTrenutni,
        obojiZauzeca,

        dajTrenutniDatum,
        dajTrenutniMjesec,
        dodajDaneKalendara,
        dajKolonuUKalendaru,
        dajSedmicuUKalendaru,
        dajZaglavljeDana,
        dajOpisDanaKolonu,
        dajNormalizovaniDanSedmice,
        dajBrojDana,
        dajIdKoloneUKalendaru
    }
}());
