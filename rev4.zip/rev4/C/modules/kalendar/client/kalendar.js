let Kalendar = (function()  {
    this.periodicniPodaci = null;
    this.vanredniPodaci = null;

    dajeVanrednePodatke = () => {
        return this.vanredniPodaci ? this.vanredniPodaci : [];
    }

    dajPeriodincePodatke = () => {
        return this.periodicniPodaci ? this.periodicniPodaci : [];
    }

    podaciPromjenjeni = (kalendarElement, podaciRezervacije) => {
        this.obojiZauzeca(kalendarElement, KalendarPrikaz.dajTrenutniMjesec(), podaciRezervacije.sala,
            podaciRezervacije.pocetak, podaciRezervacije.kraj);
    }

    obojiZauzeca = (kalendarRef, mjesec, sala, vrijemePocetka, vrijemeKraja) => {
        KalendarPrikaz.obojiZauzeca(kalendarRef, mjesec, sala, vrijemePocetka, vrijemeKraja);
    }

    daLiJeIstiZauzet = (zauzece, pocetak, kraj, sala, osoba) => {
        const salaId = zauzece.salaId ? zauzece.salaId.toString() : zauzece.naziv;
        const osobaId = zauzece.osobaId ? zauzece.osobaId.toString() : zauzece.predavac;
        const zauzet =  zauzece.pocetak === pocetak &&
            zauzece.kraj === kraj && salaId === sala;
        if (osoba) {
            return zauzet && osobaId === osoba;
        }

        return zauzet;
    }

    // Pronadjem broj dana u mjesecu i onda od prvog do zadnjeg kreiram Date objekat i poredim sa podacima koje imam
    dajZauzeteDatume = (sala, vrijemePocetka, vrijemeKraja, osoba = null) => {

        const datum = KalendarPrikaz.dajTrenutniDatum();
        const { zadnji } = KalendarPomocne.dajPocetakIKrajMjeseca(datum);
        let zauzetiDatumi = [];
        const periodicna = Rezervacija.dajPeriodicnu();
        let brojDana = zadnji.getDate();
        const trenutniMjesec = datum.getMonth();
        const semestar = KalendarPomocne.dajSemestarZaMjesec(trenutniMjesec + 1);
        
        let zauzetiPeriodicno = null, zauzetiVanredni = null;
        for (let i = 1; i <= brojDana;i++) {
            const trenutniDatum = new Date(datum.getFullYear(), trenutniMjesec, i);

            if (periodicna && semestar) {
                zauzetiPeriodicno = this.dajPeriodincePodatke().filter(pp => {
                    let danUSedmiciUKojemJeZauzeta = false;
                    const dan = (KalendarPrikaz.dajNormalizovaniDanSedmice(trenutniDatum));
                    if (dan === pp.dan) {
                        danUSedmiciUKojemJeZauzeta = true;
                    }

                    const mjesecUSemestru = pp.semestar === semestar;
                    return danUSedmiciUKojemJeZauzeta && mjesecUSemestru && 
                        this.daLiJeIstiZauzet(pp, vrijemePocetka, vrijemeKraja, sala, osoba);
                });

                if ((zauzetiPeriodicno && zauzetiPeriodicno.length > 0)) {
                    zauzetiDatumi.push(trenutniDatum);
                    continue;
                }
            }

            // Nadji zauzece na ovaj datum pa provjeri da li je za ovu salu i vrijeme
            zauzetiVanredni = this.dajeVanrednePodatke().filter((vp) => {
                const vanredniDatum = KalendarPomocne.tekstUDatum(vp.datum, "dd.mm.yyyy", ".");
                return KalendarPomocne.daLiJeDatumIsti(trenutniDatum, vanredniDatum) && 
                    this.daLiJeIstiZauzet(vp, vrijemePocetka, vrijemeKraja, sala, osoba);
            });

            if (zauzetiVanredni && zauzetiVanredni.length > 0) {
                zauzetiDatumi.push(trenutniDatum);
                continue;
            }
        }

        return zauzetiDatumi;
    }
    
    /* 
    // Periodicna zauzeca sala
    { 
        dan​: broj od 0-6 koji redom predstavlja ponedeljak do petka, 
        semestar​: “zimski” ili “ljetni”, 
        pocetak​: string u formatu “hh:mm”, ​
        kraj​: string u formatu “hh:mm”,
​        naziv​: string, 
        ​predavac​: string
    }

    // Vanredna zauzeca
    {
        ​datum​: string u formatu “dd.mm.yyyy”,
        pocetak​: string u formatu “hh:mm”,
        ​kraj​: string u formatu “hh:mm”,
        ​naziv​: string,
        ​predavac​: string
    }

    */
    ucitajPodatke = (periodicna, redovna) => {
        if (!periodicna || !redovna) {
            throw new Error('Pokusaj ucitavanje nevalidnih podataka, proslijedite listu periodicnih i redovnih zauzeca');
        }   

        periodicniPodaci = periodicna;
        vanredniPodaci = redovna;
    }

    iscrtajKalendar = (kalendarRef, mjesec) => {
        KalendarPrikaz.postaviMjesec(mjesec - 1);
        KalendarPrikaz.dodajDaneKalendara(kalendarRef);
    }

    iscrtajKalendarTrenutni = (kalendarRef) => {
        KalendarPrikaz.dodajDaneKalendara(kalendarRef);
    }

    return {
        obojiZauzeca,
        ucitajPodatke,
        iscrtajKalendar,
        iscrtajKalendarTrenutni,

        podaciPromjenjeni,
        dajZauzeteDatume
    }
}());