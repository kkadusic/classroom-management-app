class KalendarPomocna {

    constructor() {
        this.brojDanaUSedmici = 7;
        this.semestri = {
            "ljetni": {
                "id": "ljetni",
                "mjeseci": [
                    2, 3, 4, 5, 6
                ]
            },    
            "zimski": {
                "id": "zimski",
                "mjeseci": [
                    10, 11, 12, 1, 2
                ]
            }
        }
    }
    tekstUDatum(_date, _format, _delimiter) {
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf("mm");
        var dayIndex = formatItems.indexOf("dd");
        var yearIndex = formatItems.indexOf("yyyy");
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }

    normalizujDanUSedmiciULokalniDan(danUSedmici) {
        if (danUSedmici === 0) {
            danUSedmici = brojDanaUSedmici;
        }
        return danUSedmici - 1;
    }

    dajSemestarZaMjesec (mjesec) {
        const daLiJeLjetni = this.semestri.ljetni.mjeseci.indexOf(mjesec) > -1;
        if (daLiJeLjetni) {
            return semestri.ljetni.id;
        }
    
        const daLiJeZimski = this.semestri.zimski.mjeseci.indexOf(mjesec) > -1;
        if (daLiJeZimski) {
            return this.semestri.zimski.id;
        } 
        return null;
    }
}


exports.KalendarPomocna = new KalendarPomocna();