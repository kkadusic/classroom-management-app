
const milisekundeUSekundi = 1000;
const osobljePonavaljanjePeriodicnoSekunde = 30;
let tokenZaPrekidIntervala = null;
function loadOsoblje() {
    const provjeraInterval = osobljePonavaljanjePeriodicnoSekunde * milisekundeUSekundi;
    tokenZaPrekidIntervala =  setInterval(() => {
        dajZauzecaOsoblja();
    }, provjeraInterval);
    dajZauzecaOsoblja();
}

function unloadOsoblje() {
    clearInterval(tokenZaPrekidIntervala);
}

function dajZauzecaOsoblja( ){
    Pozivi.dajZauzecaOsoblja(new Date().getTime(), (data) => {
        const osobljeHtml = Osoba.dajListuOsobljeHtml(data);
        const osobljeDiv = document.getElementById('osoblje');
        osobljeDiv.innerHTML = '';
        osobljeHtml.forEach((osobaHtml) => {
            osobljeDiv.appendChild(osobaHtml);
        })
    })
}

let Osoba = (function()  {
    podaci = null;

    dodajPodatke = (podaci) => {
        this.podaci = podaci;
    }

    dajPodatakPoId = (id) => {
        return this.podaci.find((data) => data.id == id);
    }

    dajOsobljeOpcijeHtml = () => {
        if (!this.podaci) {
            throw new Error("Podaci nisu postavljeni, ne mogu dobiti opcije");
        }
        
        const options = [];
        for (var i = 0; i < this.podaci.length; i++) {
            var option = document.createElement("option");
            option.value = this.podaci[i].id;
            option.text = `${this.podaci[i].ime} ${this.podaci[i].prezime}`;
            options.push(option);
        }
        return options;
    }

    dajListuOsobljeHtml = (osoblje) => {
        return osoblje.map((osoba) => {
            const kolona = document.createElement('div');
            kolona.classList = "kolona";
            const predavac = document.createElement('div');
            predavac.classList += "predavac element";
            predavac.innerHTML = `${osoba.ime} ${osoba.prezime}`;
            const uloga = document.createElement('div');
            uloga.classList += "uloga element";
            uloga.innerHTML = osoba.uloga;
            const lokacija = document.createElement('div');
            lokacija.classList = "lokacija element";
            lokacija.innerHTML = osoba.lokacija;
            // Dodavanju u div kolonu 
            kolona.appendChild(predavac);
            kolona.appendChild(uloga);
            kolona.appendChild(lokacija);
            return kolona;
        });
    }

    return {
        dodajPodatke,
        dajPodatakPoId,
        
        dajOsobljeOpcijeHtml,
        dajListuOsobljeHtml
    }
}());