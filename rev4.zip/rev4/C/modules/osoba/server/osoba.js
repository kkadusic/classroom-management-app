const upiti = require('./upiti.servis'),
    rezervacijaUpit  = require('../../rezervacija/server/upiti.servis'),
    rezervacijaPomocna = require('../../rezervacija/server/pomocna'),
    corePomocna = require('./../../core/server/pomocna');

exports.dajZauzecaOsobljaNaDatum = function(timestamp) {
    const datum = new Date(parseInt(timestamp));
    const validan = corePomocna.daLiJeValidanDatum(datum);

    if (!validan) {
        return new Promise((_, rej) => rej('Nevalidan datum poslat'));
    }
    const osoblje = upiti.dajOsoblje();
    const rezervacijePoDatumu = rezervacijaUpit.dajRezervacijuPoDatumu(datum);
    return Promise.all([osoblje, rezervacijePoDatumu])
        .then((data) => {
            const osobljePodaci = data[0];
            const rezervacijePoDatumuPodaci = data[1];
            const osobljeZauzeca = osobljePodaci.map((osoba) => {
                const rezervacija = rezervacijePoDatumuPodaci.find((rez) => osoba.id === rez.osoba);

                let lokacija = 'U kancelariji';
                if (rezervacija) {
                    const rezervacijaNormalizovana = rezervacijaPomocna.dajRezervisanaPodatke(rezervacija);
                    lokacija = `U sali ${rezervacijaNormalizovana.sala} od ${rezervacijaNormalizovana.pocetak} do ${rezervacijaNormalizovana.kraj}`;
                }
                let normalizovanaOsoba = {...osoba, lokacija};
                return normalizovanaOsoba;
            });
            return new Promise((res, _) => res(osobljeZauzeca));
        })
}