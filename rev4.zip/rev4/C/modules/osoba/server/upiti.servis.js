const db = require('../../core/server/database/db');

exports.dajOsoblje = () => {
    return db.osoblje.findAll({raw: true});
}

exports.dajOsobu = (id) => {
    return db.osoblje.findOne({ where:{id}});
}

exports.dodajOsobu = (osoba) => {
    return db.osoblje.create(osoba);
}