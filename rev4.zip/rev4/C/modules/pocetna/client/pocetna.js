
// Pocetna stranica 
function dajElementZaSliku(slika) {
    const div = document.createElement('div');
    div.classList = 'gridElement';
    const img = document.createElement('img');
    img.src = slika;
    div.appendChild(img);
    return div;
}

function sakrijLoaderPrikaziSadrzaj() {
    const spinner = document.getElementsByClassName('lds-spinner')[0];
    spinner.style.display = 'none';
    document.getElementById('listaSlika').style.display = 'grid';
}

function pokaziLoaderSakrijSadrzaj() {
    const spinner = document.getElementsByClassName('lds-spinner')[0];
    spinner.style.display = 'block';
    document.getElementById('listaSlika').style.display = 'none';
}

function postaviSlike(slike) {
    const slikaParent = document.getElementById('listaSlika');
    if (slike.length <= 0) {
        // Jer je kod pritiska na sljedecu povecana stranica
        Pocetna.postaviSveSlikeVracene();
        toogleIskljucenSljedeci(true);
        return;
    }

    slikaParent.innerHTML = '';
    slike.forEach(slika => {
        slikaParent.appendChild(dajElementZaSliku(slika));
    });
}

function loadSlika() {
    Pozivi.dajStranicuSlika(Pocetna.dajPodatkeZaPoziv(), (slike) => {
        this.postaviSlike(slike);
        Pocetna.dodajSlike(slike);
        Pocetna.dodjeliMaksimalnuDostignutu();
    });
}

function toogleIskljucenPrethodni(disabled) {
    document.getElementById("prethodni").disabled = disabled;
}

function toogleIskljucenSljedeci(disabled) {
    document.getElementById("sljedeci").disabled = disabled;
}

function sljedeci() {
    Pocetna.povecajStranicu();
    if (!Pocetna.daLiImaSljedeciFetch()) {
        loadSlika();
    } else {
        this.postaviSlike(Pocetna.dajTrenutneSlike());
    }
    toogleIskljucenPrethodni(false);
}

function prethodni() {
    if (Pocetna.daLiJePocetakSlika()) {
        toogleIskljucenPrethodni(true);
        return;
    }
    toogleIskljucenSljedeci(false);
    Pocetna.smanjiStranicu();
    this.postaviSlike(Pocetna.dajTrenutneSlike());
}

let Pocetna = (function () {
    limit = 3;
    stranica = 0;
    maxDostignutaStranica = 0;
    slikeVracene = false;
    slike = [];

    daLiJePocetakSlika = () => {
        return this.stranica <= 0;
    }

    povecajStranicu = () => {
        this.stranica++;
    }

    dodjeliMaksimalnuDostignutu = () => {
        if (this.maxDostignutaStranica < this.stranica) {
            this.maxDostignutaStranica = this.stranica;
        }
    }

    smanjiStranicu = () => {
        this.stranica--;
        if (this.stranica < 0) {
            this.stranica = 0;
        }
    }

    daLiJeStranicaIspodMaksimalneDohvacene = () => {
        return this.maxDostignutaStranica >= this.stranica;
    }

    dodajSlike = (noveSlike) => {
        if (this.daLiSuSveSlikeVracene()) {
            return;
        }

        this.slike.push(...noveSlike);
    }

    daLiImaSljedeciFetch = () => {
        return this.daLiSuSveSlikeVracene() || this.daLiJeStranicaIspodMaksimalneDohvacene();
    }

    postaviSveSlikeVracene = () => {
        this.slikeVracene = true;
        this.smanjiStranicu();
    }

    daLiSuSveSlikeVracene = () => {
        return this.slikeVracene;
    }

    dajTrenutneSlike = () => {
        let pocetak = stranica * limit;
        const kraj = pocetak + limit;
        const trenutneSlike = slike.slice(pocetak, kraj);
        return trenutneSlike;
    }

    dajPodatkeZaPoziv = () => {
        return { page: stranica, limit: limit};
    }

    return {
        daLiJePocetakSlika,
        dodajSlike,
        povecajStranicu,
        smanjiStranicu,
        dajTrenutneSlike,
        dajPodatkeZaPoziv,
        postaviSveSlikeVracene,
        daLiSuSveSlikeVracene,
        daLiImaSljedeciFetch,
        dodjeliMaksimalnuDostignutu
    }
}());

window.onload = loadSlika;