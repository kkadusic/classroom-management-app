const slike = [
    "https://frontendmasters.com/books/front-end-handbook/2018/images/web-tech-employed.jpg",
    "https://frontendmasters.com/books/front-end-handbook/2018/images/web-tech-employed.jpg",
    "https://frontendmasters.com/books/front-end-handbook/2018/images/web-tech-employed.jpg",
    "https://static.makeuseof.com/wp-content/uploads/2017/10/html5-whats-new-670x335.jpg",
    "https://frontendmasters.com/books/front-end-handbook/2018/images/web-tech-employed.jpg",
    "https://static.makeuseof.com/wp-content/uploads/2017/10/html5-whats-new-670x335.jpg",
    "https://www.goodcore.co.uk/blog/wp-content/uploads/2019/08/coding-vs-programming-2.jpg",
    "https://static.makeuseof.com/wp-content/uploads/2017/10/html5-whats-new-670x335.jpg",
    "https://www.tutorialrepublic.com/lib/images/javascript-illustration.png",
    "https://www.tutorialrepublic.com/lib/images/javascript-illustration.png",
    "https://www.goodcore.co.uk/blog/wp-content/uploads/2019/08/coding-vs-programming-2.jpg"
];

const dajSlike = function(page, limit) {
    let pocetak = page * limit;
    const kraj = pocetak + limit;
    const trenutneSlike = slike.slice(pocetak, kraj);
    return trenutneSlike;
}

exports.dajPaginacijuSlika = function(req) {
    let page = req.query.page;
    let limit = req.query.limit;
    if (typeof page !== 'number') {
        page = parseInt(page);
    }

    if (typeof limit !== 'number') {
        limit = parseInt(limit);
    }
    const slike = dajSlike(page, limit);
    return slike;
}