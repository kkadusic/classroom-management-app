// Html funkcije
function inicijalizacijaKalendara() {
    dodajOsoblje();
    dodajSale();

    dodajKalendar(() => inicijalizujFormu());
}

function dodajKalendar(callback = null) {
    Pozivi.ucitajRezervacije((podaci) => {
        this.prikaziKalendar(podaci);
        if (callback) {
            callback();
        }
    })
}

function dodajOsoblje() {
    Pozivi.ucitajOsobe((podaci) => {
        const osobaDiv = document.getElementById('izborOsobe');
        Osoba.dodajPodatke(podaci);
        const opcije = Osoba.dajOsobljeOpcijeHtml(podaci);
        for(const opcija of opcije) {
            osobaDiv.appendChild(opcija);
        }

        dajPocetnuOsobu();
    })
}

function dodajSale() {
    Pozivi.ucitajSale((podaci) => {
        Sale.dodajPodatke(podaci);
        const salaDiv = document.getElementById('izborSale');
        const opcije = Sale.dajSaleOpcijeHtml();
        for(const opcija of opcije) {
            salaDiv.appendChild(opcija);
        }

        dajPocetnuSalu();
    })
}

function inicijalizujFormu() {
    const pocetak = document.getElementsByName("pocetak")[0];
    const kraj = document.getElementsByName("kraj")[0];
    pocetak.value = '12:00';
    kraj.value = '13:00';
    pocetak.dispatchEvent(new Event('change'));
    kraj.dispatchEvent(new Event('change'));
}

function prikaziKalendar(podaci) {
    Kalendar.ucitajPodatke(podaci.periodicna, podaci.vanredna);
    Kalendar.iscrtajKalendarTrenutni(dajKalendarElement());

    KalendarPrikaz.postaviOpisMjeseca();
    KalendarPrikaz.postaviOpisGodine();
    KalendarPrikaz.dodajDaneKalendara();
    this.promjenaPodataka();
}

function sljedeci() {
    const sljedeciMjesec = KalendarPrikaz.dajTrenutniDatum().getMonth() + 1;
    /*if (sljedeciMjesec > 11) {
        toogleIskljucenSljedeci(true);
        return;
    }*/

    KalendarPrikaz.postaviTrenutni(new Date(KalendarPrikaz.opisGodine(), sljedeciMjesec));
    dodajKalendar();
    toogleIskljucenPrethodni(false);
}

function prethodni() {
    const prethodniMjesec = KalendarPrikaz.dajTrenutniDatum().getMonth() - 1;
    /*if (prethodniMjesec < 0) {
        toogleIskljucenPrethodni(true);
        return;
    }*/
    KalendarPrikaz.postaviTrenutni(new Date(KalendarPrikaz.opisGodine(), prethodniMjesec));
    dodajKalendar();
    toogleIskljucenSljedeci(false);
}

function dajPocetnuSalu() {
    const e = document.getElementById("izborSale");
    const sala = e.options[e.selectedIndex].value;
    Rezervacija.postaviSalu(sala);
}

function dajPocetnuOsobu() {
    const e = document.getElementById("izborOsobe");
    const osoba = e.options[e.selectedIndex].value;
    Rezervacija.postaviOsobu(osoba);
}

function izaberiSalu(event) {
    Rezervacija.postaviSalu(event.value);
}

function izaberiPeriodicnu(event) {
    Rezervacija.postaviPeriodicnu(event.checked);
}

function izaberiPocetak(event) {
    const pocetak = (event.value);
    Rezervacija.postaviPocetak(pocetak);
}

function izaberiKraj(event) {
    // Dodavanje sekundi u vrijeme kao na BE
    const kraj = (event.value);
    Rezervacija.postaviKraj(kraj);
}

function izaberiOsobu(event) {
    Rezervacija.postaviOsobu(event.value);
}

function toogleIskljucenPrethodni(disabled) {
    document.getElementById("prethodni").disabled = disabled;
}

function toogleIskljucenSljedeci(disabled) {
    document.getElementById("sljedeci").disabled = disabled;
}

function dajKalendarElement() {
    return document.getElementById("tabelaKalendar");
}

function postaviVrijednosti() {
    const podaci = Rezervacija.dajPodatkeRezervacije();
    if (podaci.sala) {
        const sala = document.getElementsByName("sale")[0];
        sala.value = podaci.sala;
    }

    if (podaci.periodicna) {
        const periodicna = document.getElementsByName("periodicna")[0];
        periodicna.value = podaci.periodicna ? 'on' : 'off';
    }

    if (podaci.pocetak) {
        const pocetak = document.getElementsByName("pocetak")[0];
        pocetak.value = podaci.pocetak;
    }

    if (podaci.kraj) {
        const kraj = document.getElementsByName("kraj")[0];
        kraj.value = podaci.kraj;
    }
}

let Rezervacija = (function()  {
    this.pocetakZauzeca = null;
    this.krajZauzeca = null;
    this.sala = null;
    this.periodicna = null;
    this.osoba = null;

    dajSalu = () => {
        return this.sala;
    }

    dajPocetak = () => {
        return this.pocetakZauzeca;
    }

    dajKraj = () => {
        return this.krajZauzeca;
    }

    dajPeriodicnu = () => {
        return this.periodicna;
    }

    daLiSuUneseniSviPodaciZaNovuRezervaciju = () => {
        return this.krajZauzeca && this.pocetakZauzeca && this.dajSalu;
    }


    postaviSalu = (sala) => {
        this.sala = sala;
        this.promjenaPodataka();
    }

    postaviPocetak = (pocetak) => {
        this.pocetakZauzeca = pocetak;
        this.promjenaPodataka();
    }

    postaviKraj = (kraj) => {
        this.krajZauzeca = kraj;
        this.promjenaPodataka();
    }

    postaviPeriodicnu = (periodicna) => {
        this.periodicna = periodicna;
        this.promjenaPodataka();
    }

    postaviOsobu = (osoba) => {
        this.osoba = osoba;
        this.promjenaPodataka();
    }

    promjenaPodataka = () => {
        if (this.sala && this.pocetakZauzeca && this.krajZauzeca) {
            Kalendar.iscrtajKalendarTrenutni(dajKalendarElement());
            Kalendar.podaciPromjenjeni(dajKalendarElement(), this.dajPodatkeRezervacije());
        }
    }

    dajPodatkeRezervacije = () => {
        return {
            pocetak: this.pocetakZauzeca,
            kraj: this.krajZauzeca,
            periodicna: this.periodicna,
            sala: this.sala,
            osoba: this.osoba
        };
    }

    dajRezervisanaPoruku = function(data) {
        return `Nije moguće rezervisati salu ${data.naziv} za navedeni datum ${data.datum} i termin od ${data.pocetak} do ${data.kraj}!`;
    }

    rezervisiNaKlikEvent = (event) => {
        const vecZauzeta = event.target.querySelector('.zauzeta');
        const podaci = this.dajPodatkeRezervacije();
        let novaRezervacija = {
            "datum": event.target.id,
            "pocetak": podaci.pocetak,
            "kraj": podaci.kraj,
            "naziv": podaci.sala,
            "periodicna": podaci.periodicna,
            "predavac": podaci.osoba
        }

        // FE provjera da li je vec zauzeta
        if (vecZauzeta) {
            alert(this.dajRezervisanaPoruku(novaRezervacija));
            return;
        }

        if (this.daLiSuUneseniSviPodaciZaNovuRezervaciju()) {
            const datum = KalendarPomocne.tekstUDatum(event.target.id, "dd.mm.yyyy", ".");
            const odgovor = confirm(`Da li zelite rezervisati termin: ${datum.toDateString()}`);

            if (odgovor) {
                if (podaci.periodicna) {
                    const semestar = KalendarPomocne.dajSemestarZaMjesec(datum.getMonth() + 1);
                    novaRezervacija['dan'] = KalendarPrikaz.dajNormalizovaniDanSedmice(datum);
                    novaRezervacija['semestar'] = semestar;
                }

                Pozivi.spasiRezervaciju(novaRezervacija, (data) => {
                    this.prikaziKalendar(data);
                }, (error)  => {
                    console.error('Greska', error);
                    alert(error.message);
                    // Za update kalendara sa novim zauzecem ako postoje
                    if (error.data) {
                        this.prikaziKalendar(error.data);
                    }
                });
            }
        }
    }

    return {
        dajSalu,
        dajPocetak,
        dajKraj,
        dajPeriodicnu,
        dajPodatkeRezervacije,

        postaviSalu,
        postaviPocetak,
        postaviKraj,
        postaviPeriodicnu,
        postaviOsobu,
        rezervisiNaKlikEvent
    }
}());

window.onload = inicijalizacijaKalendara;