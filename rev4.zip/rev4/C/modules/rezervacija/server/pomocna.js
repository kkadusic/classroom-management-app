const KalendarPomocna = require('../../kalendar/server/kalendar-pomocna').KalendarPomocna;

const istiPocetakKrajINaziv = (d, trenutno) => {
    return d.pocetak === trenutno.pocetak 
            && d.kraj === trenutno.kraj && d.naziv === trenutno.naziv;
}

function daLiJePeriodicnoZauzece(zauzeca, trenutno) {
    return !!zauzeca.periodicna.find(d => istiPocetakKrajINaziv(d, trenutno) && d.dan === trenutno.dan && d.semestar === trenutno.semestar);
}

function daLiJeVanrednoZauzece(zauzeca, trenutno) {
    return !!zauzeca.vanredna.find(d => istiPocetakKrajINaziv(d, trenutno) && d.datum === trenutno.datum);
}

function datumURedovno(trenutnoZauzece) {
    const datum = KalendarPomocna.tekstUDatum(trenutnoZauzece.datum, "dd.mm.yyyy", ".");
    const semestar = KalendarPomocna.dajSemestarZaMjesec(datum.getMonth());
    if (semestar) {
        const vanrednoPretvorenoURedovno = {...trenutnoZauzece, dan: KalendarPomocna.normalizujDanUSedmiciULokalniDan(datum.getDay()), semestar: semestar};
        return vanrednoPretvorenoURedovno;
    }
    return trenutnoZauzece;
}

function daLiJeVanredniUPeriodnicnimZauzecima(zauzeca, vanrednoZauzece) {
    return daLiJePeriodicnoZauzece(zauzeca, vanrednoZauzece);
}

function daLiJeIspravnoVrijeme(vrijeme) {
    return /(?:[01]\d|2[0123]):(?:[012345]\d)/.test(vrijeme);
}

function dajPunoIme (ime, prezime) {
    return `${ime} ${prezime}`;
}

exports.datumURedovno = datumURedovno;

exports.daLiJeIspravnoVrijeme = daLiJeIspravnoVrijeme 

exports.daLiJeRezervisana = function(zauzeca, trenutno) {
    if (trenutno.periodicna) {
        return daLiJePeriodicnoZauzece(zauzeca, trenutno);
    }
    // Pretvaranje vrijednosti u bool
    const zauzetaVanredno = daLiJeVanrednoZauzece(zauzeca, trenutno);
    if (zauzetaVanredno) {
        return zauzetaVanredno;
    }

    return daLiJeVanredniUPeriodnicnimZauzecima(zauzeca, trenutno);
}

exports.dajRezervisanaPoruku = function(termin, datum) {
    const data = this.dajRezervisanaPodatke(termin);
    return `Nije moguće rezervisati salu ${data.sala} za navedeni datum ${datum} i termin od ${data.pocetak} do ${data.kraj}. Salu je vec rezervisao/la: ${data.predavac}!`;
}

exports.dajRezervisanaPodatke = function(rez) {
    const osoba = rez.get('rezervacijaOsoblja');
    const sala = rez.get('salaRezervisana');
    const termin = rez.get('rezervisaniTermin');

    return {
        sala: sala.naziv,
        datum: termin.datum,
        pocetak: termin.pocetak,
        kraj: termin.kraj,
        predavac: dajPunoIme(osoba.ime, osoba.prezime)
    }
}

exports.pretvoriDbRezervacijuUViewModel = function(rezervacija) {
    const rezervisaniTermin = rezervacija.get('rezervisaniTermin');
    const rezervacijaOsoblja = rezervacija.get('rezervacijaOsoblja');
    const salaRezervisana = rezervacija.get('salaRezervisana');
    const tip = rezervisaniTermin.redovni ? 'periodicna': 'vanredna';
    const datum = rezervisaniTermin.datum;
    const semestar = rezervisaniTermin.semestar;
    const dan = rezervisaniTermin.dan;
    const data = {
        "tip": tip,
        "terminId": rezervisaniTermin.id,
        "salaId": salaRezervisana.id,
        "osobaId": rezervacijaOsoblja.id,
        "pocetak": rezervisaniTermin.pocetak,
        "kraj": rezervisaniTermin.kraj,
        "naziv": salaRezervisana.naziv,
        "predavac": dajPunoIme(rezervacijaOsoblja.ime, rezervacijaOsoblja.prezime)
    }

    // Vezano za periodicno zauzece
    if (dan != null && semestar != null) {
        data["dan"] = dan;
        data["semestar"] = semestar;
    }

    // Vezano za vanredno zauzece
    if (datum != null) {
        data["datum"] = datum;
    }

    return data;
}

exports.validirajINormalizujRezervaciju = function(rezervacija) {
    const redovni = rezervacija.periodicna ? true : false;
    const normalizovanRezervacija = {
        osoba: rezervacija.predavac,
        sala: rezervacija.naziv,
        pocetak: rezervacija.pocetak,
        kraj: rezervacija.kraj,
        redovni: redovni
    }

    const ispravanPocetak = daLiJeIspravnoVrijeme(rezervacija.pocetak);
    const ispravanKraj = daLiJeIspravnoVrijeme(rezervacija.kraj);
    if (!ispravanKraj || !ispravanPocetak) {
        return;
    }

    const dan = rezervacija.dan;
    if (dan != null) {
        if (dan < 0 || dan > 6) {
            return;
        }
        normalizovanRezervacija.dan = dan;
        normalizovanRezervacija.semestar = rezervacija.semestar;
    } else {
        normalizovanRezervacija.datum = rezervacija.datum;
    }
    return normalizovanRezervacija;
}