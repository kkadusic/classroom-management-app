const rezervacijaPomocna = require('./pomocna'),
    upitiServis = require('./upiti.servis');

const dajTermine = function() {
    return upitiServis.dajRezervacije()
        .then((rezervacije) => {
            const normalizovaneRezervacije = rezervacije.reduce((acc, ele) => {
                const rez = rezervacijaPomocna.pretvoriDbRezervacijuUViewModel(ele);
                const tip = `${rez.tip}`;
                // Brisanje tipa jer nije potreban u view modelu
                delete rez.tip;

                acc[tip] = (acc[tip] ? acc[tip] : []).concat([rez]);
                return acc;
            }, {});
            return new Promise((resolve, _) => resolve(normalizovaneRezervacije));
        });
}

exports.dajTermine = dajTermine;

exports.rezervisiTermin = function(req,res){
    let bodyData = {...req.body};
    const normalizovanaRezervacija = rezervacijaPomocna.validirajINormalizujRezervaciju(bodyData);
    if (!normalizovanaRezervacija) {
        return res.status(400).json({
            message: 'Neispravni podaci poslati'
        })
    }

    upitiServis.dajRezervacijuPoKriteriju(normalizovanaRezervacija)
        .then((termin) => {
            if (termin) {
                // Dobavi nove podatke da se prikazu na FE
                return dajTermine()
                    .then((data) => {
                        const rezervisanaPoruka = rezervacijaPomocna.dajRezervisanaPoruku(termin, bodyData.datum);
                        res.status(400).json({
                            data,
                            message: rezervisanaPoruka
                        })
                    });
            }
        
            upitiServis.dodajTermin(normalizovanaRezervacija)
                    .then((kreiraniTermin) => {
                        const rezervacija = { termin: kreiraniTermin.id, sala: bodyData.naziv, osoba: bodyData.predavac }
                        upitiServis.dodajRezervaciju(rezervacija)
                            .then((spasenaRezervacija) => {
                                if (spasenaRezervacija) {
                                    return dajTermine()
                                        .then((data) => {
                                            res.json(data);
                                        });
                                } 
                                return res.status(500).send({
                                        message: 'Problem sa spasavanjem rezervacije'
                                    });
                            });
                });
        });

}