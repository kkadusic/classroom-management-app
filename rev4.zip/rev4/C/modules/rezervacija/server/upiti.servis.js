const db = require('../../core/server/database/db');
const Sequelize = require('sequelize');
const moment = require('moment');

exports.dajRezervacije = () => {
    return db.rezervacija.findAll({ include:[
        {
            model: db.osoblje,
            as: 'rezervacijaOsoblja' 
        },
        {
            model: db.termin, 
            as: 'rezervisaniTermin'
        },
        {
            model: db.sala, 
            as: 'salaRezervisana'
        }
    ]});
}

exports.dajRezervaciju = (id) => {
    return db.rezervacija.findOne({ where:{id}});
}

exports.dajRezervacijuPoKriteriju = (kriteriji) => {
    let terminWhere = {
        pocetak: kriteriji.pocetak,
        kraj: kriteriji.kraj,
    }

    if (kriteriji.redovni) {
        terminWhere = {
            ...terminWhere, 
            semestar: kriteriji.semestar,
            dan: kriteriji.dan
        };
    } else {
        terminWhere = {...terminWhere, datum: kriteriji.datum };
    }

    return db.rezervacija.findOne({
        include:[
            {
                model: db.osoblje,
                as: 'rezervacijaOsoblja',
            },
            {
                model: db.termin, 
                as: 'rezervisaniTermin',
                where: terminWhere
            },
            {
                model: db.sala, 
                as: 'salaRezervisana',
                where: {
                    id: kriteriji.sala
                }
            }
        ]
    });
}

exports.dajRezervacijuPoDatumu = (datum) => {
    const vrijeme = moment(datum).format("HH:mm:ss");
    const datumFormatiran = moment(datum).format('DD.MM.YYYY');

    // Where upit koji provjerava da li je trenutno vrijeme izmedju pocetka i kraja nekog termina ili datum da je isti kao danasnji
    const terminWhere =  {
        where: Sequelize.and(
            { 
                pocetak: {
                    [Sequelize.Op.lte]: vrijeme
                } ,
                kraj: {
                    [Sequelize.Op.gte]: vrijeme
                },
            },
            Sequelize.or(
                { 
                    datum: {
                        [Sequelize.Op.eq]: datumFormatiran
                    } 
                }
            )
        )
    }

    return db.rezervacija.findAll({
        include:[
            {
                model: db.osoblje,
                as: 'rezervacijaOsoblja',
            },
            {
                model: db.termin, 
                as: 'rezervisaniTermin',
                ...terminWhere
            },
            {
                model: db.sala, 
                as: 'salaRezervisana',
            }
        ]
    });
}

exports.dodajRezervaciju = (rezervacija) => {
    return db.rezervacija.create(rezervacija);
}

exports.dodajTermin = (termin) => {
    return db.termin.create(termin);
}