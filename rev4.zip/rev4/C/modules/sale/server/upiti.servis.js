const db = require('../../core/server/database/db');

exports.dajSale = () => {
    return db.sala.findAll({include:[
        {
            model: db.osoblje,
            as: 'osobaZaSalu'
        }], raw: true});
}

exports.dajSalu = (id) => {
    return db.sala.findOne({ where:{id}});
}

exports.dodajSalu = (sala) => {
    return db.sala.create(sala);
}