module.exports = (function() {
    const rezervacijaRoute = '/rezervacije';
    const osobljeRoute = '/osoblje';
    const saleRoute = '/sale';
    const slikeRoute = '/slike';
    const zauzecaOsoblje = '/zauzeca';

    return {
        rezervacije: {
            bazna: rezervacijaRoute
        },
        osoblje: {
            bazna: osobljeRoute,
            zauzeca: `${osobljeRoute}${zauzecaOsoblje}`
        },
        sale: {
            bazna: saleRoute
        },
        slike: {
            bazna: slikeRoute
        }
    }
}())