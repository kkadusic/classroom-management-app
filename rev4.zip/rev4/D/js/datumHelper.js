/*function jelPrestupna(year) {
    return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}

function dajDaneMjeseca(mjesec, godina) {
    if (mjesec == 0 || mjesec == 2 || mjesec == 4 || mjesec == 6 || mjesec == 7 || mjesec == 9 || mjesec == 11) return 31;
    else if (mjesec == 3 || mjesec == 5 || mjesec == 8 || mjesec == 10) return 30;
    else if (mjesec == 1 && jelPrestupna(godina)) return 29;
    else if (mjesec == 1 && !jelPrestupna(godina)) return 28;
}

function dajPrviDanMjeseca(mjesec, godina) {
    const now = new Date();


    var k = new Date(godina, mjesec, 1);
    if (k.getDay() == 0) return 7;
    else return k.getDay();
}

function dajNazivMjeseca(mjesec) {
    if (mjesec == 0) return "Januar";
    if (mjesec == 1) return "Februar";
    if (mjesec == 2) return "Mart";
    if (mjesec == 3) return "April";
    if (mjesec == 4) return "Maj";
    if (mjesec == 5) return "Juni";
    if (mjesec == 6) return "Juli";
    if (mjesec == 7) return "August";
    if (mjesec == 8) return "Septembar";
    if (mjesec == 9) return "Oktobar";
    if (mjesec == 10) return "Novembar";
    if (mjesec == 11) return "Decembar";
}

function mjesecUSemestru(mjesec) {
    if (mjesec == 0 || mjesec == 9 || mjesec == 10 || mjesec == 11) return "zimski";
    else if (mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5) return "ljetni";
    else return "greska"
}

function daLiVrijemeUpadaUDomen(pocetakZauzeca, krajZauzeca, pocetakInput, krajInput) {
    console.log(pocetakInput + "<-->" + krajInput + "    " + pocetakZauzeca + "<-->" + krajZauzeca);
    if (uporediVremena(pocetakInput, pocetakZauzeca) && uporediVremena(krajZauzeca, krajInput)) return true;
    else if (uporediVremena(pocetakZauzeca, pocetakInput) && uporediVremena(pocetakInput, krajZauzeca)) return true;
    else if (uporediVremena(pocetakZauzeca, krajInput) && uporediVremena(krajZauzeca, krajInput)) return true;
    else return false;
    /*
    if ((uporediVremena(pocetakZauzeca, pocetakInput) && uporediVremena(krajZauzeca, pocetakInput)) || (uporediVremena(krajInput, pocetakZauzeca) && uporediVremena(krajInput, krajZauzeca))) return false;
    else return true;
}

function uporediVremena(a, b) {
    return new Date('1/1/1999 ' + a + ':00') <= new Date('1/1/1999 ' + b + ':00');
}*/