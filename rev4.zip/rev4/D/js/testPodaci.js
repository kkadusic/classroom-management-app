function test2Periodicna() {
    let periodicna = [];
    return periodicna;
}

function test2Vanredna() {
    let vanredna = [{
            datum: "12.11.2019",
            pocetak: "10:00",
            kraj: "11:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
        {
            datum: "12.11.2019",
            pocetak: "10:00",
            kraj: "11:00",
            naziv: "VA1",
            predavac: "Zeljko Juric"
        },
    ]
    return vanredna;
}

function test3Periodicna() {
    let periodicna = [{
        dan: 2,
        semestar: "ljetni",
        pocetak: "10:00",
        kraj: "11:00",
        naziv: "VA1",
        predavac: "Zeljko Juric"
    }]
    return periodicna;
}

function test3Vanredna() {
    let vanredna = [];
    return vanredna;
}