let months = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
let mjeseci = document.getElementById("mjesec");
var tmjesec;

let Kalendar = (function(){    
      var periodicni=[];
      var vandredni=[];
      function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj)
      {
        var aid1=[];
        var aid2=[];
        for(var g= 0;g<periodicni.length ; g++)
        {
          if(pocetak == periodicni[g].pocetak && kraj == periodicni[g].kraj && sala == periodicni[g].sala)
          {
            if( (mjesec >9 && mjesec <12) || (mjesec>=0 && mjesec<2) )
            {
              if(periodicni[g].semestar == "zimski")
              {
                aid1.push(periodicni[g]);
              }
            }
            else
            {
              if(periodicni[g].semestar == "ljetni")
              {
                aid1.push(periodicni[g]);
              }
            }
          }
        }
        for(var m= 0;m<vandredni.length ; m++)
        {
          if(pocetak == vandredni[m].pocetak && kraj == vandredni[m].kraj && sala == vandredni[m].sala)
          {
            aid2.push(vandredni[m]);
          }
        }
        let firstDay = (new Date(2019, mjesec)).getDay();
        let daysInMonth = 32 - new Date(2019, mjesec, 32).getDate();

        let tbl = kalendarRef.getElementsByTagName("tbody")[0];

        tbl.innerHTML = "";
        mjeseci.innerHTML = months[mjesec];
        tmjesec = mjesec;

        let date = 1;
        for (let i = 0; i < 6; i++) {
            let row = document.createElement("tr");
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < firstDay) {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode("");
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                }
                else if (date > daysInMonth) {
                    break;
                }
                else {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode(date);
                    var cellStil = document.createAttribute("class");
                    cellStil.value = "slobodna";
                    cell.setAttributeNode(cellStil);
                    for(var k = 0; k < aid1.length;k++)
                    {
                      if(aid1[k].dan ===new Date(2019,mjesec,date).getDay())
                      {
                        
                        cellStil.value = "demo zauzeta";
                        cell.setAttributeNode(cellStil);
                      }
                    }
                    for(var h=0;h<aid2.length;h++)
                    {
                      if(new Date(aid2[h].datum).getDate() == new Date(2019,mjesec,date).getDate() && new Date(aid2[h].datum).getMonth() == new Date(2019,mjesec,date).getMonth()  && new Date(aid2[h].datum).getFullYear() == new Date(2019,mjesec,date).getFullYear())
                      {
                      cellStil.value = "demo2 zauzeta";
                      cell.setAttributeNode(cellStil);
                      }
                    }
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                    date++;
                }
            }
            tbl.appendChild(row); 
        }
      }     
      function ucitajPodatkeImpl(periodicna, vandredna)
      { 
        periodicni=periodicna;
        vandredni=vandredna;     
      }    
      function iscrtajKalendarImpl(kalendarRef,mjesec)
      {
        let firstDay = (new Date(2019, mjesec)).getDay();
        let daysInMonth = 32 - new Date(2019, mjesec, 32).getDate();

        let tbl = kalendarRef.getElementsByTagName("tbody")[0];

        tbl.innerHTML = "";
        mjeseci.innerHTML = months[mjesec];
        tmjesec = mjesec;

        let date = 1;
        for (let i = 0; i < 6; i++) {
            let row = document.createElement("tr");
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < firstDay) {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode("");
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                }
                else if (date > daysInMonth) {
                    break;
                }
                else {
                    let cell = document.createElement("td");
                    let cellText = document.createTextNode(date);
                    cell.appendChild(cellText);
                    row.appendChild(cell);
                    date++;
                }
            }
            tbl.appendChild(row); 
        }
      }
       
       return {
        obojiZauzeca: obojiZauzecaImpl,         
        ucitajPodatke: ucitajPodatkeImpl,         
        iscrtajKalendar: iscrtajKalendarImpl  
         }     
        }() );

function naredni() {
          if(tmjesec >=0 && tmjesec <11)
          {
          tmjesec = tmjesec + 1;
          //Kalendar.iscrtajKalendar(document.getElementById("kalendar"),tmjesec);
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
          }
      }
      
function prethodni() {
        if(tmjesec >0 && tmjesec <12)
        {
        tmjesec = tmjesec - 1;
        Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
        }
      }
function draw()
{ 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),tmjesec,document.getElementById("sale").value,document.getElementById("pocetak").value.toString(),document.getElementById("kraj").value.toString());
}

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 2);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 3);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 4);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 5);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 6);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 7);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 8);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 9);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 11);
// Testovi za iscrtavanje kalendara sa različitim vrijednostima
var periodicno1 = {dan: 1, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno2 = {dan: 3, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno3 = {dan: 4, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var vandredna1 = {datum: "2019-11-15",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna2 = {datum: "2019-11-21",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var p=[];
var p1=[];
var v1=[];
var v=[];
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa praznim zauzecima
p.push(periodicno1);
p.push(periodicno2);
p.push(periodicno3);
v.push(vandredna1);
v.push(vandredna2);
Kalendar.ucitajPodatke(p,v);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa parcijalno punim zauzecima, i preklapanjem dana
var periodicno4 = {dan: 0, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno5 = {dan: 2, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno6 = {dan: 5, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno7 = {dan: 6, semestar:"zimski",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var vandredna3 = {datum: "2019-11-16",sala:"0-01",pocetak:"14:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna4 = {datum: "2019-11-27",sala:"0-01",pocetak:"13:00", kraj:"16:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna5 = {datum: "2019-12-16",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
var vandredna6 = {datum: "2019-12-27",sala:"0-01",pocetak:"13:00", kraj:"15:00",naziv:"IM",predavac:"H. Fatkic"};
p.push(periodicno4);
p.push(periodicno5);
p.push(periodicno6);
p.push(periodicno7);
v.push(vandredna3);
v.push(vandredna4);
v.push(vandredna5);
v.push(vandredna6); // Ubacujemo metode koje se ne smiju upisati poput različitog mjeseca ili vremena
Kalendar.ucitajPodatke(p,v); // Overwrite test 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test sa svim zauzecima
Kalendar.ucitajPodatke(p1,v); // Test sa 1 prazan 1 pun array
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
Kalendar.ucitajPodatke(p,v1); // Test sa 1 prazan 1 pun array
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
var periodicno8 = {dan: 1, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno9 = {dan: 3, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
var periodicno10 = {dan: 4, semestar:"ljetni",sala:"0-01", pocetak:"13:00", kraj:"15:00", naziv:"IM",predavac:"H. Fatkic"};
p.push(periodicno8);
p.push(periodicno9);
p.push(periodicno10);
Kalendar.ucitajPodatke(p,v);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),3,"0-01","13:00","15:00"); // Test ljetnog semestra, samo određeni dani se trebaju obojit
p1.push(periodicno4);
p1.push(periodicno5);
p1.push(periodicno6);
v1.push(vandredna1);
v1.push(vandredna2);
p1.push(periodicno8);
p1.push(periodicno9);
p1.push(periodicno10);
Kalendar.ucitajPodatke(p1,v1);
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); // Test zimskog semestra 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00"); 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","13:00","15:00");  // Test poziva iste metode više puta jedna nakon druge 
Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"1-15","13:00","15:00");