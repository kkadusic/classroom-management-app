window.onload=function(){
    dobavi();
}

function dobavi()
{
    let h1;
    let h2;
    let tbl = document.getElementsByTagName("tbody")[0];
    tbl.innerHTML = "";
    var ajax = new XMLHttpRequest();
    ajax.open("GET","/osoblje",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
    ajax.onload = function()
    {
      var jsonRez = JSON.parse(ajax.responseText);
      h1 = jsonRez;
      //console.log(jsonRez);
    }
    setTimeout(() => {
    var ajax = new XMLHttpRequest();
    ajax.open("POST","http://localhost:8080",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
    ajax.onload = function()
    {
        var jsonRez = JSON.parse(ajax.responseText);
        h2 = jsonRez;
        //console.log(jsonRez);
    }
    }, 150);
    setTimeout(() => {
        /*var Danas = new Date(2019, 10, 5, 13, 15, 0);
        d = 0;*/
        var Danas = new Date();
        var d = Danas.getDay();
        var dd = Danas.getDate();
        var mm = Danas.getMonth()+1;
        var yy = Danas.getFullYear();
        var str = yy+"-"+mm+"-"+dd;
        var tt = Danas.getHours() + ":" + Danas.getMinutes();
        //console.log(tt);
        //console.log(h1,h2)
        for(i=0;i<h1.length;i++)
        {
          let row = document.createElement("tr");
          let cell = document.createElement("td");
          let cell2 = document.createElement("td");
          let cellText = document.createTextNode(h1[i]);
          let cell2Text = document.createTextNode("U kancelariji");
          {
              for(j=0;j<h2.length;j++)
              {  
                if(h1[i] == h2[j].predavac)
                {
                  if(h2[j].tip == "periodicno" && h2[j].dan == d)
                  {
                    if( (mm >=9 && mm <12) || (mm>=0 && mm<1) )
                    {
                        if(h2[j].semestar == "zimski" && h2[j].dan == d)
                        {
                            if(tt >= h2[j].pocetak && tt<= h2[j].kraj)
                            {
                                cell2Text = document.createTextNode(h2[j].sala);
                            }
                        }
                    }
                    else
                    {
                        if(h2[j].semestar == "ljetni" && h2[j].dan == d)
                        {
                            if(tt >= h2[j].pocetak && tt<= h2[j].kraj)
                            {
                                cell2Text = document.createTextNode(h2[j].sala);
                            }  
                        }
                    }
                  }
                  if(h2[j].tip == "vandredno")
                  {
                      if(h2[j].datum == str)
                      {
                        if(tt >= h2[j].pocetak && tt<= h2[j].kraj)
                            {
                                cell2Text = document.createTextNode(h2[j].sala);
                            } 
                     }
                  }
                }
              }
          }
          cell.appendChild(cellText);
          cell2.appendChild(cell2Text);
          row.appendChild(cell);
          row.appendChild(cell2);
          tbl.appendChild(row); 
        }
      }, 1500);
}