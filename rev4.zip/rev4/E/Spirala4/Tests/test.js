let assert = require('assert');
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../index.js');
let should = chai.should();

chai.use(chaiHttp)

before(done =>{
    server.on('start',function(){
        done();
    })
})

describe('GET /osoblje', () =>{
    describe('Is there any response?',function() {
        it('Should be status 200'),function(done){
            chai.request(server)
                .get('/osoblje')
                .end((err,res) => {
                    res.should.have.status(200);
                    done();
                })
            }
        })
    })
    describe('GET', () =>{
        describe('Is there any response?',function() {
            it('Should be status 200'),function(done){
                chai.request(server)
                    .get('')
                    .end((err,res) => {
                        res.should.have.status(200);
                        done();
                    })
                }
            })
        })
        describe('POST', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
     describe('POST /cell', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/cell')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
 describe('POST /setslika', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/setslika')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
describe('POST /dobaviSlika', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/dobaviSlika')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
describe('POST /set0', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/set0')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
describe('POST /set1', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/set1')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
describe('POST /set2', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/set2')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })
describe('POST /set3', () =>{
            describe('Is there any response?',function() {
                it('Should be status 200'),function(done){
                    chai.request(server)
                        .post('/set3')
                        .end((err,res) => {
                            res.should.have.status(200);
                            done();
                        })
                    }
                })
            })