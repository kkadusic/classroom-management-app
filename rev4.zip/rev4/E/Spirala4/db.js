const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19","root","root",{host:"127.0.0.1",dialect:"mysql",logging:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

db.Osoblje = sequelize.import(__dirname+'/Osoblje.js');
db.Termin = sequelize.import(__dirname+'/Termin.js');
db.Sala = sequelize.import(__dirname+'/Sala.js');
db.Rezervacija = sequelize.import(__dirname+'/Rezervacija.js');

//db.Osoblje.hasMany(db.Rezervacija,{as:'rezervacije'});
db.Rezervacija.belongsTo(db.Osoblje,{as:'zauzeo',through:'osobe_rezervisale',foreignKey:'osoba'});
db.Rezervacija.belongsTo(db.Termin,{as:'zauzece',through:'termini_rezervacija',foreignKey:'termin'});
db.Rezervacija.belongsTo(db.Sala,{as:'mjesto',through:'mjesta_rezervacija',foreignKey:'sala'});
db.Sala.belongsTo(db.Osoblje,{as:'osoba',through:'osoba_zauzece',foreignKey:'zaduzenaOsoba'});

module.exports=db;