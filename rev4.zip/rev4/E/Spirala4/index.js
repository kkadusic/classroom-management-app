const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());
app.use(express.static(__dirname));
const db = require('./db.js')

db.sequelize.sync({force:true}).then(function(){
   inicializacija().then(function(){
       console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
   });
});
function inicializacija(){
   return new Promise(function(resolve,reject){
           db.Osoblje.create({ime:"Neko",prezime:"Nekić",uloga:"profesor"}).then(function(k)
           {
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Osoblje.create({ime:"Drugi",prezime:"Neko",uloga:"asistent"}).then(function(k)
           {
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Osoblje.create({ime:"Test",prezime:"Test",uloga:"asistent"}).then(function(k)
           {
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Sala.create({naziv:"1-11", zaduzenaOsoba:1}).then(function(k)
           {
               k.setOsoba(1);
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Sala.create({naziv:"1-15", zaduzenaOsoba:2}).then(function(k)
           {
               k.setOsoba(2);
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Termin.create({redovni:false, dan:null,datum:"01.01.2020",semestar:null,pocetak:'12:00',kraj:'13:00'}).then(function(k)
           {
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Termin.create({redovni:true, dan:0,datum:null,semestar:"zimski",pocetak:'13:00',kraj:'14:00'}).then(function(k)
           {
               return new Promise(function(resolve,reject){resolve(k);});
           });
           setTimeout(() => {
               db.Rezervacija.create({termin:1,sala:1,osoba:1}).then(function(k)
           {
               k.setZauzeo(1);
               k.setZauzece(1);
               k.setMjesto(1);
               return new Promise(function(resolve,reject){resolve(k);});
           });
           db.Rezervacija.create({termin:2,sala:1,osoba:3}).then(function(k)
           {
               k.setZauzece(2);
               k.setMjesto(1);
               k.setZauzeo(3);
               return new Promise(function(resolve,reject){resolve(k);});
           });   
           }, 1000);
           /*
           setTimeout(() => {
               db.Rezervacija.findOne({where:{termin:2}}).then(function(termin){
                       console.log(termin.osoba);
                   }); 
           }, 1500);*/
           /*
           setTimeout(() => {
            ht1 = db.Rezervacija.findAll({raw:true})
            setTimeout(() => {
               console.log(ht1._rejectionHandler0[1].id);     
            }, 50);   
        }, 1800);
        */
       /*
       setTimeout(() => {
         ht1 = db.Osoblje.findAll({raw:true})
         setTimeout(() => {
            for(i=0;i<ht1._rejectionHandler0.length;i++){
            console.log(ht1._rejectionHandler0[i].ime + " " + ht1._rejectionHandler0[i].prezime); 
         }    
         }, 50);      
      }, 2000);
      */
           setTimeout(() => {
               app.emit('start');  
               resolve();
           },2500);
       }).catch(function(err){console.log(err);});
}

app.get('/',function(req,res){
    res.sendFile(__dirname+"/Rezervacija.html");
    //console.log(req.header('user-agent'));
    //console.log(req.header('x-forwarded-for') || req.connection.remoteAddress);
    var fs=require('fs');
    fs.readFile(__dirname+"/promet.json", 'utf8',function(err,data)
    {
    var traffic=JSON.parse(data);
    var objekt = {browser:req.header('user-agent'),adresa:req.header('x-forwarded-for') || req.connection.remoteAddress};
    traffic.push(objekt);
    //console.log(traffic);
    var fs = require('fs');
    fs.writeFile(__dirname+"/promet.json", JSON.stringify(traffic),'utf8',function(err)
    {
       if(err) throw err;
    });
    });  
 });

 app.get('/osoblje',function(req,res){
   ht1 = db.Osoblje.findAll({raw:true})
   var osobe = [];
   setTimeout(() => {
      for(i=0;i<ht1._rejectionHandler0.length;i++)
      {
      //console.log(ht1._rejectionHandler0[i].ime + " " + ht1._rejectionHandler0[i].prezime);
      osobe.push(ht1._rejectionHandler0[i].uloga+ " " + ht1._rejectionHandler0[i].ime + " " + ht1._rejectionHandler0[i].prezime)
      }
      
   }, 50);
   setTimeout(() => {
      res.send(osobe);
   }, 100);   
 });
 
app.post('/',function(req,res){
    ht2 =  db.Rezervacija.findAll({raw:true});
    var ar = []
    var sr={tip:"vandredno",datum:"2019-11-30",sala:0-01,pocetak:"10:00",kraj:"13:00",naziv:"IM",predavac:"profesor Neko Nekić"};
    var er={tip:"periodicno",dan:1,semestar:"zimski",sala:"0-01",pocetak:"13:00",kraj:"13:00",naziv:"IM",predavac:"profesor Neko Nekić"};
    setTimeout(() => {
      //console.log(ht2);
      for(i=0;i<ht2._rejectionHandler0.length;i++)
      {
         //console.log(ht2._rejectionHandler0[i].termin + " " + ht2._rejectionHandler0[i].sala + " " + ht2._rejectionHandler0[i].osoba)
         (function(i) {
         setTimeout(function() {
               return new Promise(function(resolve,reject){
                     db.Termin.findOne({where:{id:ht2._rejectionHandler0[i].termin}}).then(function(k)
                     {
                        setTimeout(() => {
                        //console.log(k.dataValues.id);   
                        if(k.dataValues.redovni == false)
                        {
                           db.Sala.findOne({where:{id:ht2._rejectionHandler0[i].sala }}).then(function(j)
                           {
                              //console.log(j.dataValues.naziv);
                              sr.sala = j.dataValues.naziv;
                              return new Promise(function(resolve,reject){resolve(j);});  
                           });
                           db.Osoblje.findOne({where:{id:ht2._rejectionHandler0[i].osoba}}).then(function(h)
                           {
                              //console.log(k.dataValues.id);
                              sr.predavac = h.dataValues.uloga+ " "  + h.dataValues.ime + " " +  h.dataValues.prezime;
                              return new Promise(function(resolve,reject){resolve(h);});
                           });
                           setTimeout(() => {
                              datum = k.dataValues.datum.substr(5,4) + "-" + k.dataValues.datum.substr(2,2) + "-" + k.dataValues.datum.substr(0,1);
                              if(k.dataValues.datum.length == 10)
                              {
                                 datum = k.dataValues.datum.substr(6,4) + "-" + k.dataValues.datum.substr(3,2) + "-" + k.dataValues.datum.substr(0,2);
                              }
                              //console.log(datum);
                              sr.datum = datum;
                              sr.pocetak = k.dataValues.pocetak;
                              sr.kraj = k.dataValues.kraj;
                              sas = {tip:sr.tip,datum:sr.datum,sala:sr.sala,pocetak:sr.pocetak,kraj:sr.kraj,naziv:sr.naziv,predavac:sr.predavac};
                              ar.push(sas);                             
                           }, 80);
                        }
                        else 
                        {
                           //console.log(k.dataValues.dan)
                              db.Sala.findOne({where:{id:ht2._rejectionHandler0[i].sala }}).then(function(j)
                              {
                                 //console.log(j.dataValues.naziv);
                                 er.sala = j.dataValues.naziv;
                                 return new Promise(function(resolve,reject){resolve(j);});  
                              });
                              db.Osoblje.findOne({where:{id:ht2._rejectionHandler0[i].osoba}}).then(function(h)
                              {
                                 //console.log(k.dataValues.id);
                                 er.predavac = h.dataValues.uloga+ " "  + h.dataValues.ime + " " +  h.dataValues.prezime;
                                 return new Promise(function(resolve,reject){resolve(h);});
                              });
                              setTimeout(() => {
                                 er.dan= k.dataValues.dan;
                                 er.semestar =k.dataValues.semestar;
                                 er.pocetak = k.dataValues.pocetak;
                                 er.kraj = k.dataValues.kraj;
                              vas = {tip:er.tip,dan:er.dan,semestar:er.semestar,sala:er.sala,pocetak:er.pocetak,kraj:er.kraj,naziv:er.naziv,predavac:er.predavac};
                              //console.log(vas);
                              ar.push(vas); 
                              }, 80);                      
                        }
                         return new Promise(function(resolve,reject){resolve(k);});
                     }, 60);
                     });  
               });
           }, 90);
      })(i);
      }
    }, 100);
    setTimeout(() => {
      //console.log(ar);
      res.send(ar)
    }, 800);
 });

 let sedmica = ["nedeljom","ponedeljkom","utorkom","srijedom","četvrtkom","petkom","subotom"];
 app.post('/cell',function(req,res){
    //console.log(req.body);
    str = "Termin uspješno rezervisan"
    var r = 0;
    var ht10 =  db.Rezervacija.findAll({raw:true});
    var str;
    var sala;
      //console.log(ht10);
      setTimeout(() => {
      for(i=0;i<ht10._rejectionHandler0.length;i++)
      { 
         (function(i) {
            setTimeout(function(){
               return new Promise(function(resolve,reject){
                  db.Termin.findOne({where:{id:ht2._rejectionHandler0[i].termin}}).then(function(k)
                  { 
                     db.Sala.findOne({where:{id:ht10._rejectionHandler0[i].sala }}).then(function(j)
                     {
                        //console.log(j.dataValues.naziv);
                        sala = j.dataValues.naziv;
                        return new Promise(function(resolve,reject){resolve(j);});  
                     });
                     setTimeout(() => {
                        if (req.body.sala == sala)
                        {  
                           if(req.body.pocetak == k.dataValues.pocetak.substr(0,5) || k.dataValues.kraj.substr(0,5) == req.body.pocetak || (req.body.pocetak >=  k.dataValues.pocetak.substr(0,5) && req.body.pocetak <=  k.dataValues.pocetak.substr(0,5)) || (req.body.pocetak <=  k.dataValues.pocetak.substr(0,5) && req.body.kraj >= k.dataValues.kraj.substr(0,5)))
                           {
                              if(req.body.tip == "vandredno")
                              {
                                 
                                 datum = new Date(parseInt(req.body.datum.substr(0,4)),parseInt(req.body.datum.substr(5,7))-1,parseInt(req.body.datum.substr(8,req.body.datum.length))+1)
                                 if(k.dataValues.redovni == false)
                                 {
                                    dt= k.dataValues.datum.substr(5,4) + "-" + k.dataValues.datum.substr(2,2) + "-" + k.dataValues.datum.substr(0,1);
                                    if(k.dataValues.datum.length == 10)
                                    {
                                    dt= k.dataValues.datum.substr(6,4) + "-" + k.dataValues.datum.substr(3,2) + "-" + k.dataValues.datum.substr(0,2);
                                    }
                                 } 
                                 if(req.body.datum == dt || k.dataValues.dan == datum.getDay()-1)
                                 {
                                    r=1;
                                    str = "Nije moguće rezervisati salu: " + req.body.sala + " za navedeni datum: " +req.body.datum.substr(8,req.body.datum.length)+"/"+parseInt(req.body.datum.substr(5,2))+"/"+req.body.datum.substr(0,4)+" i termin od " + req.body.pocetak + " do " + req.body.kraj;   
                                 }
                              }
                              if(req.body.tip == "periodicno")
                              {
                                 datum = new Date();
                                 if(k.dataValues.redovni == false)
                                 {
                                    datum = new Date(parseInt(k.dataValues.datum.substr(5,4)),parseInt(k.dataValues.datum.substr(2,2))-1,parseInt(k.dataValues.datum.substr(0,1)));
                                    if(k.dataValues.datum.length == 10)
                                    {
                                       datum = new Date(parseInt(k.dataValues.datum.substr(6,4)),parseInt(k.dataValues.datum.substr(3,2))-1,parseInt(k.dataValues.datum.substr(0,2)));
                                    }
                                 }
                                 if (req.body.dan == k.dataValues.dan || req.body.dan == datum.getDay())
                                 {
                                    r=1;
                                    str = "Nije moguće rezervisati salu: " + req.body.sala + " " + sedmica[req.body.dan] + " i u terminu od " + req.body.pocetak + " do " + req.body.kraj + " u semestru: " +req.body.semestar ;
                                 }
                              }
                            }
                        }
                        
                     }, 100);
                     return new Promise(function(resolve,reject){resolve(k);});
                  });
               });
            }, 150);
         })(i);
      }
   }, 180);
   setTimeout(() => {
      var pid;
      var kid;
      var sid;
      if(r==0)
      {
         if(req.body.tip == "periodicno")
         {
            db.Termin.create({redovni:true, dan:req.body.dan,datum:null,semestar:req.body.semestar,pocetak:req.body.pocetak,kraj:req.body.kraj}).then(function(k)
           {
               //console.log(k.id);
               pid = k.id;
               return new Promise(function(resolve,reject){resolve(k);});
           });
         }
         if(req.body.tip == "vandredno")
         {
            var d = req.body.datum.substr(8,2) +"."+req.body.datum.substr(5,2) +"."+req.body.datum.substr(0,4);
            //console.log(d);
         db.Termin.create({redovni:false, dan:null,datum:d,semestar:null,pocetak:req.body.pocetak,kraj:req.body.kraj}).then(function(k)
           {
              //console.log(k.id);
               pid = k.id;
               return new Promise(function(resolve,reject){resolve(k);});
           });
         }
         var res = req.body.predavac.split(" ");
         db.Osoblje.findOne({where:{ime:res[1],prezime:res[2],uloga:res[0]}}).then(function(h)
         {
            //console.log(h.dataValues.id);
            kid = h.dataValues.id;
            return new Promise(function(resolve,reject){resolve(h);});
         });
         //console.log(req.body.sala);
         db.Sala.findOne({where:{naziv:req.body.sala}}).then(function(j)
         {
            sid=j.dataValues.id;
            return new Promise(function(resolve,reject){resolve(j);});
         });     
         setTimeout(() => {
         db.Rezervacija.create({termin:pid,sala:1,osoba:1}).then(function(k)
         {
            k.setZauzeo(kid);
            k.setZauzece(pid);
            k.setMjesto(sid);
            return new Promise(function(resolve,reject){resolve(k);});
         });    
           }, 50); 
      } 
   }, 500);
   setTimeout(() => {
      var odg = {odgovor:str}
      res.send(odg);  
   }, 1000); 
 });


 app.post('/set0',function(req,res){
    res.send("row1.png");
});
app.post('/set1',function(req,res){
   res.send("row2.jpg");
});
app.post('/set2',function(req,res){
   res.send("row3.jpg");
});
app.post('/set3',function(req,res){
   res.send("row4.jpg");
});

app.post('/setslika',function(req,res){
   var str = "nema";
   const fs = require("fs");
   if (fs.existsSync(__dirname+req.body.slika))
   {
         str="ima";
   }
   //console.log("ima");
   res.send(str);
});
app.post('/dobaviSlika',function(req,res){
   var sk=".png"
   if(req.body.broj > 1)
   {
      sk=".jpg";
   }
   res.send("row"+req.body.broj+sk);
});

 module.exports = app;
 app.listen(8080);
