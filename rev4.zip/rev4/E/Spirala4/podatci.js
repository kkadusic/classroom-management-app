const db = require('./db.js')
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});
function inicializacija(){
    return new Promise(function(resolve,reject){
            db.Osoblje.create({ime:"Neko",prezime:"Nekić",uloga:"profesor"}).then(function(k)
            {
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Osoblje.create({ime:"Drugi",prezime:"Neko",uloga:"asistent"}).then(function(k)
            {
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Osoblje.create({ime:"Test",prezime:"Test",uloga:"asistent"}).then(function(k)
            {
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Sala.create({naziv:"1-11", zaduzenaOsoba:1}).then(function(k)
            {
                k.setOsoba(1);
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Sala.create({naziv:"1-15", zaduzenaOsoba:2}).then(function(k)
            {
                k.setOsoba(2);
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Termin.create({redovni:false, dan:null,datum:"01.01.2020",semestar:null,pocetak:'12:00',kraj:'13:00'}).then(function(k)
            {
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Termin.create({redovni:true, dan:0,datum:null,semestar:"zimski",pocetak:'13:00',kraj:'14:00'}).then(function(k)
            {
                return new Promise(function(resolve,reject){resolve(k);});
            });
            setTimeout(() => {
                db.Rezervacija.create({termin:1,sala:1,osoba:1}).then(function(k)
            {
                k.setZauzeo(1);
                k.setZauzece(1);
                k.setMjesto(1);
                return new Promise(function(resolve,reject){resolve(k);});
            });
            db.Rezervacija.create({termin:2,sala:1,osoba:3}).then(function(k)
            {
                k.setZauzece(2);
                k.setMjesto(1);
                k.setZauzeo(3);
                return new Promise(function(resolve,reject){resolve(k);});
            });   
            }, 500);/*
            setTimeout(() => {
                db.Rezervacija.findOne({where:{termin:2}}).then(function(termin){
                        console.log(termin.osoba);
                    }); 
            }, 1500);*/
            setTimeout(() => {      
                resolve();
            },1000);
        }).catch(function(err){console.log(err);});
}